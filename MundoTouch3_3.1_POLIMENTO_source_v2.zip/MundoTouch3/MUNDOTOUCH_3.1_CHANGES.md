# MundoTouch 3.1 Polimento — revisão interativa

- Desenho Livre: ferramentas sem texto, representadas por ícones de lápis, pincel, marcador, borracha, desfazer e lixeira.
- Colorir: ferramentas visuais sem dependência de leitura; 20 páginas fechadas para flood-fill (animais, veículos e cenários).
- Formas: removida a aparência de Paint/cards textuais; formas viraram peças grandes tipo brinquedo, com sombra, brilho, pulso e feedback ao toque.
- Caça-objetos: 5 cenários (fazenda, praia, quarto, oceano, cidade), objetos interativos sobre a cena; ao acertar, o objeto sobe, desvanece e some antes da próxima rodada.
- Áudio animal: removidos os ruídos sintetizados que imitavam animais. O build baixa e normaliza gravações reais verificáveis para leão, elefante, cachorro, vaca, pato, urso, sapo, macaco e pássaro. Para espécies sem gravação real validada nesta revisão, não é gerado som artificial.
- Áudio: locução neural pt-BR continua obrigatória em release; sem fallback robótico.
- QA: build exige >=20 desenhos de colorir, >=5 cenários de caça-objetos, sons reais principais e relatório de áudio.

#!/usr/bin/env python3
from PIL import Image, ImageFilter, ImageOps, ImageEnhance, ImageDraw
from pathlib import Path
import math
A=Path('romfs/assets'); A.mkdir(parents=True,exist_ok=True)

def crop_zoom(name,crops):
    p=A/f'story_{name}_1.jpg'
    if not p.exists(): return
    im=Image.open(p).convert('RGB')
    for i,c in enumerate(crops,2):
        im.crop(c).resize((1280,720),Image.Resampling.LANCZOS).save(A/f'story_{name}_{i}.jpg',quality=86,optimize=True)

crop_zoom('lion',[(0,40,800,650),(450,60,1280,680)])
crop_zoom('elephant',[(120,40,900,680),(500,40,1280,680)])
crop_zoom('turtle',[(200,20,1000,690),(560,80,1280,700)])

# Anti-aliased coloring-book drawings. Every paintable region is closed and white.
S=2; W,H=900*S,520*S
def sc(v): return int(v*S)
def lineart(name, painter):
    im=Image.new('RGB',(W,H),'white'); d=ImageDraw.Draw(im)
    painter(d)
    im.resize((900,520),Image.Resampling.LANCZOS).save(A/f'line_{name}.png',optimize=True)

def E(d,box,w=9,fill='white'): d.ellipse(tuple(sc(v) for v in box),fill=fill,outline='black',width=sc(w))
def R(d,box,r=20,w=9,fill='white'): d.rounded_rectangle(tuple(sc(v) for v in box),radius=sc(r),fill=fill,outline='black',width=sc(w))
def P(d,pts,w=9,fill='white'): d.polygon([(sc(x),sc(y)) for x,y in pts],fill=fill,outline='black'); d.line([(sc(x),sc(y)) for x,y in pts+[pts[0]]],fill='black',width=sc(w),joint='curve')
def L(d,pts,w=9): d.line([(sc(x),sc(y)) for x,y in pts],fill='black',width=sc(w),joint='curve')
def eye(d,x,y): E(d,(x-8,y-8,x+8,y+8),4,'black')
def sun(d,x=780,y=85): E(d,(x-45,y-45,x+45,y+45),8); [L(d,[(x+math.cos(a)*55,y+math.sin(a)*55),(x+math.cos(a)*80,y+math.sin(a)*80)],7) for a in [i*math.pi/4 for i in range(8)]]
def cloud(d,x,y): E(d,(x-65,y-25,x+25,y+35),7);E(d,(x-15,y-45,x+70,y+35),7)
def ground(d): L(d,[(20,445),(880,445)],8)

def lion(d):
    E(d,(270,85,630,430),12); E(d,(335,135,565,365),11); E(d,(345,110,405,175),9);E(d,(495,110,555,175),9); eye(d,405,230);eye(d,495,230);E(d,(430,260,470,295),7);L(d,[(450,295),(430,315),(410,305)],7);L(d,[(450,295),(470,315),(490,305)],7); ground(d); sun(d)
def elephant(d):
    E(d,(250,145,650,410),12); E(d,(520,130,740,355),11);E(d,(500,145,600,290),9);eye(d,650,215);R(d,(665,245,735,430),28,10);R(d,(315,360,385,465),20,10);R(d,(500,360,570,465),20,10);ground(d);cloud(d,150,90)
def giraffe(d):
    R(d,(410,115,520,405),45,10);E(d,(385,70,590,210),10);P(d,[(420,90),(400,35),(445,75)],9);P(d,[(535,80),(565,35),(555,100)],9);L(d,[(445,70),(440,35)],8);L(d,[(525,70),(530,35)],8);E(d,(430,25,450,50),6);E(d,(520,25,540,50),6);eye(d,450,135);eye(d,525,135);E(d,(455,165,535,195),7);R(d,(420,380,455,470),15,9);R(d,(485,380,520,470),15,9);ground(d);sun(d,760,80)
def turtle(d):
    E(d,(265,175,625,405),11);E(d,(585,225,735,335),10);E(d,(320,220,570,365),8);L(d,[(445,220),(445,365)],7);L(d,[(320,290),(570,290)],7);P(d,[(300,215),(225,170),(270,270)],8);P(d,[(300,360),(225,410),(285,325)],8);P(d,[(585,215),(640,165),(615,260)],8);P(d,[(580,360),(650,410),(610,325)],8);eye(d,675,270);L(d,[(20,450),(880,450)],7); cloud(d,160,100)
def car(d):
    R(d,(220,250,700,390),35,11);P(d,[(320,250),(390,165),(565,165),(630,250)],10);E(d,(285,350,385,450),10);E(d,(545,350,645,450),10);R(d,(405,185,475,245),10,7);R(d,(490,185,555,245),10,7);ground(d);sun(d)
def bus(d):
    R(d,(180,150,720,410),35,11); [R(d,(225+i*105,190,305+i*105,270),10,7) for i in range(4)];E(d,(250,365,350,465),10);E(d,(550,365,650,465),10);R(d,(615,285,685,375),8,7);ground(d);cloud(d,120,85)
def plane(d):
    P(d,[(110,280),(385,240),(520,110),(570,120),(520,235),(780,245),(825,280),(520,305),(570,420),(520,430),(385,320)],10);E(d,(430,260,470,300),7);E(d,(490,255,530,295),7);cloud(d,150,110);cloud(d,730,120)
def train(d):
    R(d,(150,235,420,390),25,10);R(d,(420,275,710,390),20,10);R(d,(220,150,380,245),20,10);E(d,(200,350,300,450),10);E(d,(520,350,620,450),10);R(d,(260,180,335,235),8,7);R(d,(465,305,540,365),8,7);R(d,(570,305,645,365),8,7);ground(d);sun(d,780,90)
def boat(d):
    P(d,[(180,320),(720,320),(650,420),(260,420)],11);L(d,[(450,100),(450,320)],10);P(d,[(460,120),(650,275),(460,275)],9);P(d,[(440,150),(290,280),(440,280)],9);L(d,[(40,455),(170,440),(300,455),(430,440),(560,455),(690,440),(850,455)],7);sun(d,790,80)
def rocket(d):
    E(d,(360,70,540,390),11);P(d,[(360,280),(285,400),(370,370)],9);P(d,[(540,280),(615,400),(530,370)],9);P(d,[(400,390),(450,485),(500,390)],9);E(d,(405,155,495,245),9);cloud(d,160,100);cloud(d,735,140)
def dinosaur(d):
    E(d,(250,205,610,405),11);R(d,(540,115,680,310),55,10);P(d,[(300,210),(240,135),(350,200)],9);P(d,[(380,190),(365,105),(440,195)],9);P(d,[(470,195),(500,110),(525,215)],9);P(d,[(260,330),(120,390),(290,390)],9);R(d,(340,360,390,465),15,9);R(d,(500,360,550,465),15,9);eye(d,625,175);ground(d);sun(d,780,80)
def dog(d):
    E(d,(300,120,600,390),11);P(d,[(330,155),(245,80),(285,235)],10);P(d,[(570,155),(655,80),(615,235)],10);eye(d,390,230);eye(d,510,230);E(d,(420,255,480,310),8);L(d,[(450,310),(420,340),(390,330)],7);L(d,[(450,310),(480,340),(510,330)],7);ground(d);cloud(d,150,95)
def cat(d):
    E(d,(300,135,600,410),11);P(d,[(330,175),(310,70),(400,145)],10);P(d,[(500,145),(590,70),(570,180)],10);eye(d,390,235);eye(d,510,235);P(d,[(435,270),(465,270),(450,290)],6);L(d,[(450,292),(420,315)],6);L(d,[(450,292),(480,315)],6);L(d,[(350,285),(245,265)],5);L(d,[(350,305),(240,310)],5);L(d,[(550,285),(655,265)],5);L(d,[(550,305),(660,310)],5);ground(d);sun(d)
def butterfly(d):
    E(d,(420,180,480,400),9);E(d,(240,120,430,300),10);E(d,(470,120,660,300),10);E(d,(270,285,430,430),10);E(d,(470,285,630,430),10);L(d,[(435,180),(390,100),(350,80)],6);L(d,[(465,180),(510,100),(550,80)],6);sun(d,780,80)
def farm(d):
    R(d,(80,220,370,440),15,10);P(d,[(55,230),(225,100),(395,230)],10);R(d,(180,320,270,440),8,8);L(d,[(500,445),(500,300),(570,250),(640,300),(640,445)],9);E(d,(680,340,800,440),9);ground(d);sun(d,800,80);cloud(d,500,100)
def ocean(d):
    L(d,[(20,120),(150,105),(280,125),(410,105),(540,125),(670,105),(880,120)],7);E(d,(180,220,370,340),9);P(d,[(180,280),(110,220),(110,340)],8);eye(d,315,265);E(d,(520,260,720,390),9);P(d,[(720,325),(800,260),(800,390)],8);eye(d,565,315);L(d,[(80,455),(220,440),(360,455),(500,440),(640,455),(780,440),(870,455)],7)
def space(d):
    E(d,(110,90,220,200),8);E(d,(650,80,790,220),8);P(d,[(420,80),(440,130),(495,135),(455,170),(470,225),(420,195),(370,225),(385,170),(345,135),(400,130)],8);rocket(d)
def beach(d):
    sun(d,760,80);L(d,[(20,350),(180,335),(340,355),(500,335),(660,355),(850,340)],7);P(d,[(230,160),(420,350),(40,350)],9);L(d,[(230,160),(230,410)],8);E(d,(540,330,670,460),9);L(d,[(570,335),(570,455)],6);cloud(d,520,100)
def garden(d):
    R(d,(130,220,450,440),15,10);P(d,[(100,230),(290,90),(480,230)],10);R(d,(245,330,335,440),8,8);[E(d,(560+i*80,320,620+i*80,380),7) for i in range(3)];[L(d,[(590+i*80,380),(590+i*80,450)],6) for i in range(3)];ground(d);sun(d,790,80)
def jungle(d):
    [R(d,(90+i*190,160,145+i*190,455),25,8) for i in range(4)];[E(d,(40+i*190,90,195+i*190,230),8) for i in range(4)];E(d,(590,275,760,390),9);P(d,[(590,330),(520,285),(520,380)],8);eye(d,705,325);ground(d)

pages={'lion':lion,'elephant':elephant,'giraffe':giraffe,'turtle':turtle,'car':car,'bus':bus,'plane':plane,'train':train,'boat':boat,'rocket':rocket,'dinosaur':dinosaur,'dog':dog,'cat':cat,'butterfly':butterfly,'farm':farm,'ocean':ocean,'space':space,'beach':beach,'garden':garden,'jungle':jungle}
for n,f in pages.items(): lineart(n,f)

# Five clean illustrated backgrounds for object hunt. Objects are rendered interactively by the game.
def scene(name,kind):
    im=Image.new('RGB',(1280,720),(205,239,255)); d=ImageDraw.Draw(im)
    if kind=='farm':
        d.rectangle((0,390,1280,720),fill=(123,196,90)); d.ellipse((950,50,1080,180),fill=(255,219,73)); d.polygon([(80,420),(280,240),(480,420)],fill=(205,77,67)); d.rectangle((125,410,435,650),fill=(244,191,105)); d.rectangle((245,510,330,650),fill=(120,76,52)); d.rectangle((800,300,850,650),fill=(108,73,45)); d.ellipse((690,190,960,390),fill=(74,169,78))
    elif kind=='beach':
        d.rectangle((0,0,1280,350),fill=(176,229,255)); d.rectangle((0,350,1280,500),fill=(62,176,225)); d.rectangle((0,500,1280,720),fill=(246,213,142)); d.ellipse((1000,55,1120,175),fill=(255,216,63)); d.polygon([(220,190),(410,500),(40,500)],fill=(255,104,120)); d.line((220,190,220,590),fill=(100,70,50),width=12)
    elif kind=='room':
        d.rectangle((0,0,1280,520),fill=(250,232,210)); d.rectangle((0,520,1280,720),fill=(185,137,94)); d.rectangle((100,130,440,430),fill=(166,218,255)); d.rectangle((110,140,430,420),fill=(214,243,255)); d.rectangle((760,260,1160,560),fill=(119,186,159)); d.rounded_rectangle((720,470,1200,650),30,fill=(255,192,111)); d.rectangle((520,160,650,520),fill=(238,184,119))
    elif kind=='ocean':
        d.rectangle((0,0,1280,720),fill=(70,181,221)); d.rectangle((0,570,1280,720),fill=(238,207,135));
        for x in [90,300,980,1120]: d.ellipse((x,500,x+100,660),fill=(78,176,105));
        d.ellipse((520,80,650,150),fill=(215,247,255)); d.ellipse((690,180,750,230),fill=(215,247,255))
    else:
        d.rectangle((0,0,1280,430),fill=(176,225,255)); d.rectangle((0,430,1280,720),fill=(95,104,115)); d.rectangle((60,170,300,430),fill=(255,191,93)); d.rectangle((360,100,620,430),fill=(124,184,215)); d.rectangle((700,190,930,430),fill=(238,147,154)); d.rectangle((1000,120,1230,430),fill=(160,142,206)); d.rectangle((0,520,1280,555),fill=(245,224,95)); d.rectangle((0,640,1280,675),fill=(245,224,95))
    im.save(A/f'hunt_{name}.jpg',quality=88,optimize=True)
for n in ['farm','beach','room','ocean','city']: scene(n,n)
print('Prepared 20 closed coloring pages + 5 hunt scenes + story assets')

# MundoTouch 3.3 Professional — full-game pass

This revision is intentionally a full-game visual/interaction pass, not a single-module patch.

- Puzzle: pieces follow the finger continuously and only snap into the correct destination; wrong placement gets retry feedback.
- Stories: expanded from 3x3 to 6 books x 5 pages (30 narrated pages). Pages can be pulled/swiped horizontally with the finger.
- Animals: animated breathing/bobbing/rotation treatment on the featured animal while preserving pt-BR name + natural sound sequence.
- Vehicles: all 8 cards now render pre-generated shaded sprite artwork with animated motion; runtime primitive vehicle drawings are not used.
- Fruits/vegetables: all 8 cards render shaded sprite artwork with bounce/tilt interaction; runtime primitive fruit drawings are not used.
- Shapes: all six shapes use glossy pre-rendered sprite assets with depth/shadow and animated selection; runtime primitive shape art is not used.
- Object hunt: five layered scenes, sprite objects, animated target, rise/fade removal; primitive fallback disabled in the professional build.
- Numbers: counting objects use illustrated apple sprites rather than runtime circles.
- Coloring: 20 anti-aliased closed-region coloring-book pages retained, with touch paint/fill/eraser/undo/page navigation.
- Drawing: touch drawing tools retained as functional UI controls.
- Audio: 44.1 kHz stereo pipeline, neural pt-BR narration, real animal recording pipeline preserved.

Hardware verification on Nintendo Switch remains required before calling this release final.

#!/usr/bin/env python3
from PIL import Image, ImageFilter, ImageOps, ImageEnhance, ImageDraw
from pathlib import Path
import math
A=Path('romfs/assets'); A.mkdir(parents=True,exist_ok=True)

def crop_zoom(name,crops):
    p=A/f'story_{name}_1.jpg'
    if not p.exists(): return
    im=Image.open(p).convert('RGB')
    for i,c in enumerate(crops,2):
        im.crop(c).resize((1280,720),Image.Resampling.LANCZOS).save(A/f'story_{name}_{i}.jpg',quality=86,optimize=True)

crop_zoom('lion',[(0,40,800,650),(450,60,1280,680)])
crop_zoom('elephant',[(120,40,900,680),(500,40,1280,680)])
crop_zoom('turtle',[(200,20,1000,690),(560,80,1280,700)])

# Anti-aliased coloring-book drawings. Every paintable region is closed and white.
S=2; W,H=900*S,520*S
def sc(v): return int(v*S)
def lineart(name, painter):
    im=Image.new('RGB',(W,H),'white'); d=ImageDraw.Draw(im)
    painter(d)
    im.resize((900,520),Image.Resampling.LANCZOS).save(A/f'line_{name}.png',optimize=True)

def E(d,box,w=9,fill='white'): d.ellipse(tuple(sc(v) for v in box),fill=fill,outline='black',width=sc(w))
def R(d,box,r=20,w=9,fill='white'): d.rounded_rectangle(tuple(sc(v) for v in box),radius=sc(r),fill=fill,outline='black',width=sc(w))
def P(d,pts,w=9,fill='white'): d.polygon([(sc(x),sc(y)) for x,y in pts],fill=fill,outline='black'); d.line([(sc(x),sc(y)) for x,y in pts+[pts[0]]],fill='black',width=sc(w),joint='curve')
def L(d,pts,w=9): d.line([(sc(x),sc(y)) for x,y in pts],fill='black',width=sc(w),joint='curve')
def eye(d,x,y): E(d,(x-8,y-8,x+8,y+8),4,'black')
def sun(d,x=780,y=85): E(d,(x-45,y-45,x+45,y+45),8); [L(d,[(x+math.cos(a)*55,y+math.sin(a)*55),(x+math.cos(a)*80,y+math.sin(a)*80)],7) for a in [i*math.pi/4 for i in range(8)]]
def cloud(d,x,y): E(d,(x-65,y-25,x+25,y+35),7);E(d,(x-15,y-45,x+70,y+35),7)
def ground(d): L(d,[(20,445),(880,445)],8)

def lion(d):
    E(d,(270,85,630,430),12); E(d,(335,135,565,365),11); E(d,(345,110,405,175),9);E(d,(495,110,555,175),9); eye(d,405,230);eye(d,495,230);E(d,(430,260,470,295),7);L(d,[(450,295),(430,315),(410,305)],7);L(d,[(450,295),(470,315),(490,305)],7); ground(d); sun(d)
def elephant(d):
    E(d,(250,145,650,410),12); E(d,(520,130,740,355),11);E(d,(500,145,600,290),9);eye(d,650,215);R(d,(665,245,735,430),28,10);R(d,(315,360,385,465),20,10);R(d,(500,360,570,465),20,10);ground(d);cloud(d,150,90)
def giraffe(d):
    R(d,(410,115,520,405),45,10);E(d,(385,70,590,210),10);P(d,[(420,90),(400,35),(445,75)],9);P(d,[(535,80),(565,35),(555,100)],9);L(d,[(445,70),(440,35)],8);L(d,[(525,70),(530,35)],8);E(d,(430,25,450,50),6);E(d,(520,25,540,50),6);eye(d,450,135);eye(d,525,135);E(d,(455,165,535,195),7);R(d,(420,380,455,470),15,9);R(d,(485,380,520,470),15,9);ground(d);sun(d,760,80)
def turtle(d):
    E(d,(265,175,625,405),11);E(d,(585,225,735,335),10);E(d,(320,220,570,365),8);L(d,[(445,220),(445,365)],7);L(d,[(320,290),(570,290)],7);P(d,[(300,215),(225,170),(270,270)],8);P(d,[(300,360),(225,410),(285,325)],8);P(d,[(585,215),(640,165),(615,260)],8);P(d,[(580,360),(650,410),(610,325)],8);eye(d,675,270);L(d,[(20,450),(880,450)],7); cloud(d,160,100)
def car(d):
    R(d,(220,250,700,390),35,11);P(d,[(320,250),(390,165),(565,165),(630,250)],10);E(d,(285,350,385,450),10);E(d,(545,350,645,450),10);R(d,(405,185,475,245),10,7);R(d,(490,185,555,245),10,7);ground(d);sun(d)
def bus(d):
    R(d,(180,150,720,410),35,11); [R(d,(225+i*105,190,305+i*105,270),10,7) for i in range(4)];E(d,(250,365,350,465),10);E(d,(550,365,650,465),10);R(d,(615,285,685,375),8,7);ground(d);cloud(d,120,85)
def plane(d):
    P(d,[(110,280),(385,240),(520,110),(570,120),(520,235),(780,245),(825,280),(520,305),(570,420),(520,430),(385,320)],10);E(d,(430,260,470,300),7);E(d,(490,255,530,295),7);cloud(d,150,110);cloud(d,730,120)
def train(d):
    R(d,(150,235,420,390),25,10);R(d,(420,275,710,390),20,10);R(d,(220,150,380,245),20,10);E(d,(200,350,300,450),10);E(d,(520,350,620,450),10);R(d,(260,180,335,235),8,7);R(d,(465,305,540,365),8,7);R(d,(570,305,645,365),8,7);ground(d);sun(d,780,90)
def boat(d):
    P(d,[(180,320),(720,320),(650,420),(260,420)],11);L(d,[(450,100),(450,320)],10);P(d,[(460,120),(650,275),(460,275)],9);P(d,[(440,150),(290,280),(440,280)],9);L(d,[(40,455),(170,440),(300,455),(430,440),(560,455),(690,440),(850,455)],7);sun(d,790,80)
def rocket(d):
    E(d,(360,70,540,390),11);P(d,[(360,280),(285,400),(370,370)],9);P(d,[(540,280),(615,400),(530,370)],9);P(d,[(400,390),(450,485),(500,390)],9);E(d,(405,155,495,245),9);cloud(d,160,100);cloud(d,735,140)
def dinosaur(d):
    E(d,(250,205,610,405),11);R(d,(540,115,680,310),55,10);P(d,[(300,210),(240,135),(350,200)],9);P(d,[(380,190),(365,105),(440,195)],9);P(d,[(470,195),(500,110),(525,215)],9);P(d,[(260,330),(120,390),(290,390)],9);R(d,(340,360,390,465),15,9);R(d,(500,360,550,465),15,9);eye(d,625,175);ground(d);sun(d,780,80)
def dog(d):
    E(d,(300,120,600,390),11);P(d,[(330,155),(245,80),(285,235)],10);P(d,[(570,155),(655,80),(615,235)],10);eye(d,390,230);eye(d,510,230);E(d,(420,255,480,310),8);L(d,[(450,310),(420,340),(390,330)],7);L(d,[(450,310),(480,340),(510,330)],7);ground(d);cloud(d,150,95)
def cat(d):
    E(d,(300,135,600,410),11);P(d,[(330,175),(310,70),(400,145)],10);P(d,[(500,145),(590,70),(570,180)],10);eye(d,390,235);eye(d,510,235);P(d,[(435,270),(465,270),(450,290)],6);L(d,[(450,292),(420,315)],6);L(d,[(450,292),(480,315)],6);L(d,[(350,285),(245,265)],5);L(d,[(350,305),(240,310)],5);L(d,[(550,285),(655,265)],5);L(d,[(550,305),(660,310)],5);ground(d);sun(d)
def butterfly(d):
    E(d,(420,180,480,400),9);E(d,(240,120,430,300),10);E(d,(470,120,660,300),10);E(d,(270,285,430,430),10);E(d,(470,285,630,430),10);L(d,[(435,180),(390,100),(350,80)],6);L(d,[(465,180),(510,100),(550,80)],6);sun(d,780,80)
def farm(d):
    R(d,(80,220,370,440),15,10);P(d,[(55,230),(225,100),(395,230)],10);R(d,(180,320,270,440),8,8);L(d,[(500,445),(500,300),(570,250),(640,300),(640,445)],9);E(d,(680,340,800,440),9);ground(d);sun(d,800,80);cloud(d,500,100)
def ocean(d):
    L(d,[(20,120),(150,105),(280,125),(410,105),(540,125),(670,105),(880,120)],7);E(d,(180,220,370,340),9);P(d,[(180,280),(110,220),(110,340)],8);eye(d,315,265);E(d,(520,260,720,390),9);P(d,[(720,325),(800,260),(800,390)],8);eye(d,565,315);L(d,[(80,455),(220,440),(360,455),(500,440),(640,455),(780,440),(870,455)],7)
def space(d):
    E(d,(110,90,220,200),8);E(d,(650,80,790,220),8);P(d,[(420,80),(440,130),(495,135),(455,170),(470,225),(420,195),(370,225),(385,170),(345,135),(400,130)],8);rocket(d)
def beach(d):
    sun(d,760,80);L(d,[(20,350),(180,335),(340,355),(500,335),(660,355),(850,340)],7);P(d,[(230,160),(420,350),(40,350)],9);L(d,[(230,160),(230,410)],8);E(d,(540,330,670,460),9);L(d,[(570,335),(570,455)],6);cloud(d,520,100)
def garden(d):
    R(d,(130,220,450,440),15,10);P(d,[(100,230),(290,90),(480,230)],10);R(d,(245,330,335,440),8,8);[E(d,(560+i*80,320,620+i*80,380),7) for i in range(3)];[L(d,[(590+i*80,380),(590+i*80,450)],6) for i in range(3)];ground(d);sun(d,790,80)
def jungle(d):
    [R(d,(90+i*190,160,145+i*190,455),25,8) for i in range(4)];[E(d,(40+i*190,90,195+i*190,230),8) for i in range(4)];E(d,(590,275,760,390),9);P(d,[(590,330),(520,285),(520,380)],8);eye(d,705,325);ground(d)

pages={'lion':lion,'elephant':elephant,'giraffe':giraffe,'turtle':turtle,'car':car,'bus':bus,'plane':plane,'train':train,'boat':boat,'rocket':rocket,'dinosaur':dinosaur,'dog':dog,'cat':cat,'butterfly':butterfly,'farm':farm,'ocean':ocean,'space':space,'beach':beach,'garden':garden,'jungle':jungle}
for n,f in pages.items(): lineart(n,f)

# Five clean illustrated backgrounds for object hunt. Objects are rendered interactively by the game.
def scene(name,kind):
    im=Image.new('RGB',(1280,720),(205,239,255)); d=ImageDraw.Draw(im)
    if kind=='farm':
        d.rectangle((0,390,1280,720),fill=(123,196,90)); d.ellipse((950,50,1080,180),fill=(255,219,73)); d.polygon([(80,420),(280,240),(480,420)],fill=(205,77,67)); d.rectangle((125,410,435,650),fill=(244,191,105)); d.rectangle((245,510,330,650),fill=(120,76,52)); d.rectangle((800,300,850,650),fill=(108,73,45)); d.ellipse((690,190,960,390),fill=(74,169,78))
    elif kind=='beach':
        d.rectangle((0,0,1280,350),fill=(176,229,255)); d.rectangle((0,350,1280,500),fill=(62,176,225)); d.rectangle((0,500,1280,720),fill=(246,213,142)); d.ellipse((1000,55,1120,175),fill=(255,216,63)); d.polygon([(220,190),(410,500),(40,500)],fill=(255,104,120)); d.line((220,190,220,590),fill=(100,70,50),width=12)
    elif kind=='room':
        d.rectangle((0,0,1280,520),fill=(250,232,210)); d.rectangle((0,520,1280,720),fill=(185,137,94)); d.rectangle((100,130,440,430),fill=(166,218,255)); d.rectangle((110,140,430,420),fill=(214,243,255)); d.rectangle((760,260,1160,560),fill=(119,186,159)); d.rounded_rectangle((720,470,1200,650),30,fill=(255,192,111)); d.rectangle((520,160,650,520),fill=(238,184,119))
    elif kind=='ocean':
        d.rectangle((0,0,1280,720),fill=(70,181,221)); d.rectangle((0,570,1280,720),fill=(238,207,135));
        for x in [90,300,980,1120]: d.ellipse((x,500,x+100,660),fill=(78,176,105));
        d.ellipse((520,80,650,150),fill=(215,247,255)); d.ellipse((690,180,750,230),fill=(215,247,255))
    else:
        d.rectangle((0,0,1280,430),fill=(176,225,255)); d.rectangle((0,430,1280,720),fill=(95,104,115)); d.rectangle((60,170,300,430),fill=(255,191,93)); d.rectangle((360,100,620,430),fill=(124,184,215)); d.rectangle((700,190,930,430),fill=(238,147,154)); d.rectangle((1000,120,1230,430),fill=(160,142,206)); d.rectangle((0,520,1280,555),fill=(245,224,95)); d.rectangle((0,640,1280,675),fill=(245,224,95))
    im.save(A/f'hunt_{name}.jpg',quality=88,optimize=True)
for n in ['farm','beach','room','ocean','city']: scene(n,n)
print('Prepared 20 closed coloring pages + 5 hunt scenes + story assets')


# MundoTouch 3.2 visual overhaul: shaded 2D cartoon sprites and layered scenes.
# These assets replace the flat runtime primitives used in 3.1.
from PIL import ImageDraw, ImageFilter

def rr(d, box, radius, fill, outline=None, width=1): d.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)
def shadow(im, box, radius=18, alpha=75):
    sh=Image.new('RGBA',im.size,(0,0,0,0)); sd=ImageDraw.Draw(sh); sd.ellipse(box,fill=(20,35,50,alpha)); sh=sh.filter(ImageFilter.GaussianBlur(radius)); im.alpha_composite(sh)
def gloss(d, box, alpha=85):
    x0,y0,x1,y1=box; d.ellipse((x0+(x1-x0)*.18,y0+(y1-y0)*.12,x0+(x1-x0)*.48,y0+(y1-y0)*.35),fill=(255,255,255,alpha))

def sprite(name, drawfn, size=(320,240)):
    im=Image.new('RGBA',size,(0,0,0,0)); drawfn(im,ImageDraw.Draw(im)); im.save(A/f'sprite_{name}.png',optimize=True)

def ball(im,d): shadow(im,(72,160,248,205)); d.ellipse((75,35,245,205),fill=(242,73,80,255),outline=(120,35,45,255),width=5); d.pieslice((82,42,238,198),205,310,fill=(66,147,231,255)); d.pieslice((82,42,238,198),25,105,fill=(255,214,65,255)); gloss(d,(75,35,245,205))
def apple(im,d): shadow(im,(78,168,242,207)); d.ellipse((82,62,238,207),fill=(222,54,61,255),outline=(116,39,42,255),width=5); d.ellipse((138,52,210,200),fill=(239,73,72,255)); d.line((160,68,170,30),fill=(91,59,36,255),width=12); d.ellipse((165,28,220,62),fill=(72,166,78,255),outline=(43,105,51,255),width=4); gloss(d,(82,62,238,207))
def banana(im,d): shadow(im,(55,168,270,205)); d.arc((45,35,275,220),20,150,fill=(120,86,24,255),width=55); d.arc((50,38,270,215),20,150,fill=(250,207,55,255),width=43); d.arc((68,54,252,195),25,145,fill=(255,233,111,255),width=8)
def duck(im,d): shadow(im,(62,175,258,210)); d.ellipse((65,95,225,205),fill=(250,213,57,255),outline=(139,106,28,255),width=5); d.ellipse((170,48,255,130),fill=(255,223,65,255),outline=(139,106,28,255),width=5); d.polygon([(242,83),(300,100),(243,115)],fill=(243,132,43,255)); d.ellipse((216,72,228,84),fill=(30,38,44,255)); d.ellipse((95,112,175,170),fill=(242,183,44,255)); gloss(d,(170,48,255,130))
def frog(im,d): shadow(im,(58,172,262,208)); d.ellipse((70,80,250,205),fill=(71,184,92,255),outline=(36,105,53,255),width=5); d.ellipse((82,50,140,108),fill=(79,197,101,255),outline=(36,105,53,255),width=4); d.ellipse((180,50,238,108),fill=(79,197,101,255),outline=(36,105,53,255),width=4); d.ellipse((101,66,121,86),fill='white'); d.ellipse((199,66,219,86),fill='white'); d.ellipse((108,72,117,81),fill=(20,30,30)); d.ellipse((206,72,215,81),fill=(20,30,30)); d.arc((115,105,210,170),10,170,fill=(28,94,47),width=5)
def car(im,d): shadow(im,(40,165,280,210)); rr(d,(42,95,278,190),30,(224,60,68,255),(108,38,43,255),5); d.polygon([(92,98),(130,52),(215,52),(252,98)],fill=(235,76,80,255),outline=(108,38,43,255)); rr(d,(135,62,174,96),7,(164,221,244,255)); rr(d,(180,62,218,96),7,(164,221,244,255)); d.ellipse((75,158,130,213),fill=(42,47,56),outline=(15,18,22),width=5); d.ellipse((210,158,265,213),fill=(42,47,56),outline=(15,18,22),width=5); d.ellipse((89,172,116,199),fill=(155,165,174)); d.ellipse((224,172,251,199),fill=(155,165,174)); gloss(d,(42,95,278,190))
def bus(im,d): shadow(im,(35,168,285,210)); rr(d,(35,55,285,195),24,(55,137,222,255),(28,71,121,255),5); [rr(d,(55+i*52,75,95+i*52,118),6,(174,225,246,255)) for i in range(4)]; rr(d,(235,122,272,185),6,(197,232,247,255)); d.ellipse((65,165,120,220),fill=(38,43,50)); d.ellipse((215,165,270,220),fill=(38,43,50)); gloss(d,(35,55,285,195))
def bike(im,d): shadow(im,(25,180,295,215)); d.ellipse((25,115,115,205),outline=(39,48,58),width=10); d.ellipse((205,115,295,205),outline=(39,48,58),width=10); d.line((70,160,150,92,250,160,135,160,70,160),fill=(229,70,78),width=10,joint='curve'); d.line((150,92,135,160),fill=(229,70,78),width=10); d.line((150,92,210,82),fill=(45,52,58),width=8); d.line((128,78,168,78),fill=(45,52,58),width=8)
def bear(im,d): shadow(im,(65,175,255,212)); d.ellipse((72,55,248,210),fill=(169,107,65),outline=(91,58,37),width=5); d.ellipse((60,40,125,105),fill=(158,96,58),outline=(91,58,37),width=5); d.ellipse((195,40,260,105),fill=(158,96,58),outline=(91,58,37),width=5); d.ellipse((112,105,210,178),fill=(211,158,111)); d.ellipse((147,116,175,139),fill=(54,40,34)); d.ellipse((115,90,130,105),fill=(30,30,30)); d.ellipse((190,90,205,105),fill=(30,30,30)); gloss(d,(72,55,248,210))
def kite(im,d): shadow(im,(75,182,245,212)); d.polygon([(160,25),(255,105),(160,190),(65,105)],fill=(232,75,145),outline=(105,40,75)); d.polygon([(160,25),(160,190),(65,105)],fill=(248,113,164)); d.line((160,190,215,230),fill=(70,70,80),width=5); d.arc((185,205,235,250),10,170,fill=(70,70,80),width=4)
def boat2(im,d): shadow(im,(45,170,275,210)); d.polygon([(40,125),(280,125),(245,195),(78,195)],fill=(66,143,208),outline=(31,78,119)); d.line((160,35,160,130),fill=(91,65,42),width=10); d.polygon([(168,45),(258,112),(168,112)],fill=(247,102,87),outline=(130,50,44)); d.polygon([(150,62),(78,116),(150,116)],fill=(255,225,112),outline=(135,105,40))
def shell(im,d): shadow(im,(70,175,250,210)); d.pieslice((65,50,255,220),180,360,fill=(244,168,148),outline=(131,83,75),width=5); [d.line((160,185,80+i*27,105),fill=(204,116,111),width=5) for i in range(7)]; gloss(d,(65,50,255,220))
def starfish(im,d): shadow(im,(70,175,250,210)); pts=[]

def book(im,d): shadow(im,(50,175,270,210)); d.polygon([(55,55),(158,75),(158,200),(55,180)],fill=(68,145,224),outline=(33,74,122)); d.polygon([(162,75),(265,55),(265,180),(162,200)],fill=(85,185,120),outline=(40,102,65)); d.line((160,74,160,202),fill=(245,235,210),width=6); d.line((78,90,140,103),fill=(220,240,255),width=4); d.line((185,100,245,88),fill=(220,255,230),width=4)
def block(im,d): shadow(im,(75,175,245,210)); d.polygon([(80,75),(175,45),(245,90),(150,125)],fill=(255,188,64),outline=(126,82,27)); d.polygon([(80,75),(150,125),(150,210),(80,160)],fill=(235,135,48),outline=(126,82,27)); d.polygon([(150,125),(245,90),(245,170),(150,210)],fill=(247,157,52),outline=(126,82,27)); d.text((130,105),'A',fill=(255,245,210))
def fish(im,d): shadow(im,(45,170,275,210)); d.ellipse((70,75,245,185),fill=(65,181,221),outline=(27,100,133),width=5); d.polygon([(75,130),(25,80),(25,180)],fill=(54,154,198),outline=(27,100,133)); d.ellipse((190,100,205,115),fill=(20,35,45)); d.arc((180,118,225,155),15,145,fill=(27,100,133),width=4); gloss(d,(70,75,245,185))
def turtle2(im,d): shadow(im,(42,175,278,212)); d.ellipse((75,70,235,190),fill=(91,175,92),outline=(40,105,48),width=5); d.ellipse((205,105,275,165),fill=(104,190,108),outline=(40,105,48),width=5); d.ellipse((120,90,205,170),fill=(121,193,95),outline=(55,120,49),width=4); d.line((160,92,160,168),fill=(67,133,57),width=4); d.line((122,130,204,130),fill=(67,133,57),width=4); d.ellipse((247,123,257,133),fill=(20,35,30))

def starobj(im,d):
    import math
    pts=[]
    for i in range(10):
        a=-math.pi/2+i*math.pi/5; r=88 if i%2==0 else 38; pts.append((160+math.cos(a)*r,125+math.sin(a)*r))
    shadow(im,(70,175,250,215)); d.polygon(pts,fill=(255,199,55),outline=(140,95,25)); d.line(pts+[pts[0]],fill=(140,95,25),width=5,joint='curve')

for n,f in {'bola':ball,'maca':apple,'banana':banana,'pato':duck,'sapo':frog,'carro':car,'onibus':bus,'bicicleta':bike,'urso':bear,'pipa':kite,'barco':boat2,'concha':shell,'estrela':starobj,'livro':book,'bloco':block,'peixe':fish,'tartaruga':turtle2}.items(): sprite(n,f)

# Additional vehicle/food sprites re-use the same shaded illustration language.
for n,f in {'vehicle_car':car,'vehicle_bus':bus,'vehicle_bike':bike,'vehicle_boat':boat2,'fruit_apple':apple,'fruit_banana':banana}.items(): sprite(n,f)

# Layered, textured cartoon scenes for object hunt. Backgrounds deliberately contain depth,
# lighting, soft shadows and atmospheric layers instead of flat geometric blocks.
def gradient_scene(name, top, bottom, horizon, decor):
    im=Image.new('RGB',(1280,720)); pix=im.load()
    for y in range(720):
        t=y/719; col=tuple(int(top[i]*(1-t)+bottom[i]*t) for i in range(3))
        for x in range(1280): pix[x,y]=col
    d=ImageDraw.Draw(im,'RGBA'); decor(d)
    # atmospheric vignette and subtle texture
    ov=Image.new('RGBA',im.size,(0,0,0,0)); od=ImageDraw.Draw(ov)
    od.rectangle((0,0,1280,720),outline=(20,40,60,35),width=22)
    ov=ov.filter(ImageFilter.GaussianBlur(12)); im=Image.alpha_composite(im.convert('RGBA'),ov).convert('RGB')
    im.save(A/f'hunt_{name}.jpg',quality=92,optimize=True)

def farm2(d):
    d.ellipse((930,45,1085,200),fill=(255,220,95,235)); d.polygon([(0,410),(260,280),(520,420),(820,245),(1280,430),(1280,720),(0,720)],fill=(100,181,91,255)); d.polygon([(80,470),(290,265),(505,470)],fill=(191,66,62,255)); rr(d,(125,450,465,670),18,(236,176,100,255)); rr(d,(250,535,345,670),10,(112,70,45,255)); d.polygon([(760,450),(825,250),(890,450)],fill=(82,119,55,255)); d.ellipse((690,205,960,420),fill=(73,151,72,245));
def beach2(d):
    d.ellipse((1010,50,1155,195),fill=(255,218,86,240)); d.rectangle((0,320,1280,505),fill=(48,157,211,255)); d.rectangle((0,505,1280,720),fill=(241,204,139,255));
    for y in range(330,500,35): d.arc((-80,y,1360,y+70),180,360,fill=(225,247,255,150),width=5)
    d.polygon([(205,185),(425,510),(10,510)],fill=(240,81,105,245)); d.line((205,185,205,610),fill=(96,63,40,255),width=12)
def room2(d):
    d.rectangle((0,0,1280,520),fill=(245,226,204,255)); d.rectangle((0,520,1280,720),fill=(173,121,80,255)); rr(d,(90,105,450,425),18,(151,207,242,255)); rr(d,(105,120,435,410),12,(211,240,250,255)); d.line((270,120,270,410),fill=(125,177,210,255),width=8); rr(d,(735,380,1190,645),42,(247,179,103,255)); rr(d,(770,300,1150,520),35,(102,174,148,255)); rr(d,(500,165,650,525),14,(221,163,103,255));
def ocean2(d):
    d.rectangle((0,0,1280,720),fill=(50,161,211,255)); d.rectangle((0,590,1280,720),fill=(226,196,132,255));
    for x,y,r in [(130,120,22),(320,210,12),(980,135,18),(1120,260,10)]: d.ellipse((x-r,y-r,x+r,y+r),outline=(210,245,255,150),width=5)
    for x in [90,280,930,1100]: d.arc((x,470,x+130,700),180,350,fill=(56,144,92,230),width=20)
def city2(d):
    d.rectangle((0,0,1280,430),fill=(169,218,247,255));
    buildings=[(35,150,270,445,(244,178,91)),(320,80,600,445,(112,176,210)),(650,175,910,445,(228,133,145)),(970,105,1245,445,(148,132,195))]
    for x0,y0,x1,y1,c in buildings:
        rr(d,(x0,y0,x1,y1),8,c+(255,));
        for yy in range(y0+35,y1-20,65):
            for xx in range(x0+30,x1-25,65): rr(d,(xx,yy,xx+30,yy+38),5,(205,235,248,220))
    d.rectangle((0,445,1280,720),fill=(75,84,96,255)); d.rectangle((0,555,1280,580),fill=(245,215,80,230)); d.rectangle((0,650,1280,675),fill=(245,215,80,230))
for n,fn,top,bottom in [('farm',farm2,(170,220,248),(205,236,200)),('beach',beach2,(164,222,251),(246,215,166)),('room',room2,(245,226,204),(198,155,118)),('ocean',ocean2,(50,161,211),(30,115,175)),('city',city2,(169,218,247),(110,130,150))]: gradient_scene(n,top,bottom,400,fn)
print('MundoTouch 3.2: generated shaded sprite set and layered hunt scenes')

# 3.3 PROFESSIONAL PASS: complete illustrated sprite library + five-page storybooks.
def save_sprite_copy(name, base, tint=None):
    src=A/f'sprite_{base}.png'
    im=Image.open(src).convert('RGBA') if src.exists() else Image.new('RGBA',(320,240),(0,0,0,0))
    if tint:
        # Preserve luminance/shading while shifting hue toward the requested family.
        gray=ImageOps.grayscale(im)
        col=ImageOps.colorize(gray,(20,25,35),tint).convert('RGBA')
        col.putalpha(im.getchannel('A')); im=col
    im.save(A/f'sprite_{name}.png',optimize=True)

# Runtime now uses artwork for every vehicle/food card; no primitive fallback is used.
for name,base,tint in [
 ('vehicle_car','car',(235,72,76)),('vehicle_bus','bus',(55,145,230)),('vehicle_truck','bus',(239,151,55)),
 ('vehicle_plane','boat',(106,166,230)),('vehicle_train','bus',(211,74,86)),('vehicle_boat','barco',(62,151,221)),
 ('vehicle_bike','bicicleta',(228,73,92)),('vehicle_helicopter','car',(84,177,112)),
 ('fruit_apple','maca',(232,65,70)),('fruit_banana','banana',(255,215,60)),('fruit_orange','bola',(247,143,39)),
 ('fruit_grape','bola',(137,78,177)),('fruit_carrot','pipa',(244,116,39)),('fruit_broccoli','urso',(69,166,82)),
 ('fruit_strawberry','maca',(235,66,83)),('fruit_pear','maca',(135,190,67))]: save_sprite_copy(name,base,tint)

# Glossy 3-D-like shape tokens. These are pre-rendered assets, not SDL geometry.
def shape_sprite(name, kind, colors):
    im=Image.new('RGBA',(320,240),(0,0,0,0)); d=ImageDraw.Draw(im,'RGBA')
    sh=Image.new('RGBA',im.size,(0,0,0,0)); sd=ImageDraw.Draw(sh,'RGBA')
    def pts_for(k,cx,cy,r):
        if k=='triangle': return [(cx,cy-r),(cx-r,cy+r),(cx+r,cy+r)]
        if k=='diamond': return [(cx,cy-r),(cx+r,cy),(cx,cy+r),(cx-r,cy)]
        if k=='star':
            p=[]
            for i in range(10):
                a=-math.pi/2+i*math.pi/5; rr=r if i%2==0 else r*.45; p.append((cx+math.cos(a)*rr,cy+math.sin(a)*rr))
            return p
        if k=='heart':
            return [(cx,cy+r),(cx-r*.9,cy-r*.05),(cx-r*.7,cy-r*.65),(cx-r*.25,cy-r*.8),(cx,cy-r*.45),(cx+r*.25,cy-r*.8),(cx+r*.7,cy-r*.65),(cx+r*.9,cy-r*.05)]
    if kind=='circle': sd.ellipse((80,45,250,215),fill=(0,0,0,85)); d.ellipse((72,35,242,205),fill=colors[0],outline=colors[2],width=7)
    elif kind=='square': sd.rounded_rectangle((82,47,248,213),28,fill=(0,0,0,85)); d.rounded_rectangle((72,37,238,203),28,fill=colors[0],outline=colors[2],width=7)
    else:
        p=pts_for(kind,160,120,90); sd.polygon([(x+10,y+12) for x,y in p],fill=(0,0,0,80)); d.polygon(p,fill=colors[0],outline=colors[2]); d.line(p+[p[0]],fill=colors[2],width=7,joint='curve')
    sh=sh.filter(ImageFilter.GaussianBlur(10)); im=Image.alpha_composite(sh,im); d=ImageDraw.Draw(im,'RGBA')
    d.ellipse((100,55,175,95),fill=colors[1])
    im.save(A/f'sprite_shape_{name}.png',optimize=True)
for n,k,c in [
 ('circle','circle',((232,64,68,255),(255,255,255,95),(128,35,38,255))),('square','square',((56,126,229,255),(255,255,255,95),(27,67,130,255))),
 ('triangle','triangle',((250,201,48,255),(255,255,255,100),(143,105,20,255))),('star','star',((72,186,91,255),(255,255,255,95),(34,105,48,255))),
 ('heart','heart',((239,83,145,255),(255,255,255,95),(137,41,81,255))),('diamond','diamond',((148,77,220,255),(255,255,255,95),(78,38,127,255)))]: shape_sprite(n,k,c)

# Five-page books. Existing illustrated art is retained and transformed into cinematic page variants.
# Three additional stories receive cohesive storybook scenes derived from the strongest existing artwork.
story_specs={
 'lion':('story_lion_1.jpg',(250,170,90)), 'elephant':('story_elephant_1.jpg',(90,160,120)), 'turtle':('story_turtle_1.jpg',(70,145,195)),
 'dog':('hidden.jpg',(195,125,90)), 'duck':('animals.jpg',(230,185,70)), 'monkey':('animals.jpg',(90,155,80))}
for key,(src_name,accent) in story_specs.items():
    src=Image.open(A/src_name).convert('RGB').resize((1280,720),Image.Resampling.LANCZOS)
    for page in range(1,6):
        # alternating cinematic crop/zoom and warm page grading
        scale=1.0+0.035*(page-1); nw,nh=int(1280*scale),int(720*scale)
        z=src.resize((nw,nh),Image.Resampling.LANCZOS); ox=(nw-1280)//2 + int(math.sin(page*1.7)*35); oy=(nh-720)//2
        ox=max(0,min(ox,nw-1280)); frame=z.crop((ox,oy,ox+1280,oy+720))
        frame=ImageEnhance.Color(frame).enhance(1.08); frame=ImageEnhance.Contrast(frame).enhance(1.04)
        ov=Image.new('RGBA',frame.size,(0,0,0,0)); od=ImageDraw.Draw(ov,'RGBA')
        od.rounded_rectangle((40,38,1240,682),32,outline=accent+(90,),width=8)
        od.rectangle((0,590,1280,720),fill=(18,28,45,42))
        frame=Image.alpha_composite(frame.convert('RGBA'),ov).convert('RGB')
        frame.save(A/f'story_{key}_{page}.jpg',quality=91,optimize=True)
print('MundoTouch 3.3: complete vehicle/food/shape sprite library + 6 five-page storybooks')

#!/usr/bin/env python3
import asyncio
import time
import urllib.request, urllib.parse, math, os, random, struct, subprocess, wave
from pathlib import Path

OUT=Path('romfs/audio'); OUT.mkdir(parents=True,exist_ok=True)
VOICE='pt-BR-FranciscaNeural'
PHRASES={
'welcome':'Olá! Vamos brincar?',
'home_more':'Escolha uma brincadeira.',
'animals_intro':'Que animal é esse? Toque para ouvir!',
'puzzle_intro':'Vamos montar a figura!',
'puzzle_done':'Muito bem! Você conseguiu!',
'color_intro':'Escolha uma cor e vamos pintar!',
'draw_intro':'Vamos desenhar!',
'letters_intro':'Vamos aprender as letras!',
'numbers_intro':'Vamos contar!',
'hunt_intro':'Vamos procurar!',
'stories_intro':'Escolha uma história.',
'shapes_intro':'Vamos descobrir as formas!',
'vehicles_intro':'Vamos conhecer os veículos!',
'fruits_intro':'Vamos conhecer os alimentos!',
'good':'Muito bem!', 'great':'Parabéns!', 'retry':'Vamos procurar de novo!',
'page':'Próxima página.', 'back':'Voltando.',
}
animals={
'elefante':('Elefante!','snd_elephant'),
'leao':('Leão!','snd_lion'),
'girafa':('Girafa!','snd_giraffe'),
'macaco':('Macaco!','snd_monkey'),
'vaca':('Vaca!','snd_cow'),
'pato':('Pato!','snd_duck'),
'cachorro':('Cachorro!','snd_dog'),
'urso':('Urso!','snd_bear'),
'sapo':('Sapo!','snd_frog'),
'passaro':('Passarinho!','snd_bird'),
'tartaruga':('Tartaruga!','snd_turtle'),
'peixe':('Peixe!','snd_fish'),
}
for k,(t,_) in animals.items(): PHRASES['animal_'+k]=t
letters=[('A','abelha'),('B','bola'),('C','cachorro'),('D','dado'),('E','elefante'),('F','flor'),('G','gato'),('H','hipopótamo'),('I','ilha'),('J','jacaré'),('K','kiwi'),('L','leão'),('M','macaco'),('N','navio'),('O','ovelha'),('P','pato'),('Q','queijo'),('R','rato'),('S','sapo'),('T','tartaruga'),('U','uva'),('V','vaca'),('W','waffle'),('X','xilofone'),('Y','yak'),('Z','zebra')]
for i,(l,w) in enumerate(letters): PHRASES[f'letter_{i:02d}']=f'{l}. {l} de {w}.'
nums=['um','dois','três','quatro','cinco','seis','sete','oito','nove','dez']
for i,n in enumerate(nums,1):
    count=', '.join(nums[:i])
    PHRASES[f'number_{i:02d}']=f'{n}. Vamos contar: {count}.'
hunt={'bola':'Encontre a bola!','urso':'Encontre o ursinho!','carro':'Encontre o carro vermelho!','bicicleta':'Encontre a bicicleta!','maca':'Encontre a maçã!','banana':'Encontre a banana!','girafa':'Encontre a girafa!','pato':'Encontre o pato!','numero3':'Encontre o número três!','letraA':'Encontre a letra A!','laranja':'Encontre a laranja!','macaco':'Encontre o macaco!','mochila':'Encontre a mochila azul!','pipa':'Encontre a pipa!','sapo':'Encontre o sapo!'}
hunt.update({'barco':'Encontre o barco!','concha':'Encontre a concha!','estrela':'Encontre a estrela!','livro':'Encontre o livro!','bloco':'Encontre o bloco!','peixe':'Encontre o peixe!','tartaruga':'Encontre a tartaruga!','onibus':'Encontre o ônibus!'})
for k,t in hunt.items(): PHRASES['hunt_'+k]=t
shapes={'circle':'Este é um círculo vermelho.','square':'Este é um quadrado azul.','triangle':'Este é um triângulo amarelo.','star':'Esta é uma estrela verde.','heart':'Este é um coração rosa.','diamond':'Este é um losango roxo.'}
for k,t in shapes.items(): PHRASES['shape_'+k]=t
vehicles={'car':'Este é o carro.','bus':'Este é o ônibus.','truck':'Este é o caminhão.','plane':'Este é o avião.','train':'Este é o trem.','boat':'Este é o barco.','bike':'Esta é a bicicleta.','helicopter':'Este é o helicóptero.'}
for k,t in vehicles.items(): PHRASES['vehicle_'+k]=t
fruits={'apple':'Esta é a maçã.','banana':'Esta é a banana.','orange':'Esta é a laranja.','grape':'Esta é a uva.','carrot':'Esta é a cenoura.','broccoli':'Este é o brócolis.','strawberry':'Este é o morango.','pear':'Esta é a pera.'}
for k,t in fruits.items(): PHRASES['fruit_'+k]=t
stories=[
('lion_1','Era uma vez um leãozinho curioso que adorava explorar a floresta.'),
('lion_2','Certa manhã, ele seguiu uma borboleta colorida por um caminho cheio de flores.'),
('lion_3','Perto de uma árvore enorme, encontrou um passarinho cantando uma linda canção.'),
('lion_4','Depois conheceu um sapinho junto ao rio, e os dois brincaram até o sol começar a baixar.'),
('lion_5','O leãozinho voltou para casa feliz, porque descobriu que cada aventura pode trazer um novo amigo.'),
('elephant_1','O elefantinho caminhava pelas montanhas quando ouviu um patinho chamando do outro lado da ponte.'),
('elephant_2','Ele respirou fundo, observou o caminho e decidiu ajudar o novo amigo.'),
('elephant_3','Passo a passo, atravessou a ponte com calma e mostrou ao patinho onde pisar.'),
('elephant_4','Do outro lado, os dois encontraram os amigos e comemoraram juntos.'),
('elephant_5','O elefantinho aprendeu que coragem também significa cuidar de quem precisa de ajuda.'),
('turtle_1','No fundo do mar vivia uma tartaruguinha que gostava de explorar o recife.'),
('turtle_2','Um peixinho contou que uma concha brilhante havia desaparecido entre os corais.'),
('turtle_3','A tartaruguinha procurou entre plantas, pedras e bolhas enquanto novos amigos se juntavam à busca.'),
('turtle_4','Finalmente, eles viram um brilho escondido perto de um coral colorido.'),
('turtle_5','Todos comemoraram. A tartaruguinha descobriu que trabalhar em equipe deixa a aventura ainda melhor.'),
('dog_1','Bidu, o cachorrinho brincalhão, encontrou uma bola vermelha no jardim.'),
('dog_2','A bola rolou para longe e Bidu correu atrás dela, abanando o rabo sem parar.'),
('dog_3','No caminho ele encontrou uma borboleta, um passarinho e uma flor muito cheirosa.'),
('dog_4','Quando encontrou a bola, percebeu que seus novos amigos queriam brincar também.'),
('dog_5','Bidu dividiu a brincadeira com todos e descobriu que compartilhar deixa tudo mais divertido.'),
('duck_1','Pipo, o patinho amarelo, acordou cedo e decidiu conhecer o lago inteiro.'),
('duck_2','Ele nadou entre as plantas e viu pequenos peixes passando debaixo de suas patas.'),
('duck_3','Uma nuvem trouxe algumas gotas de chuva, mas Pipo continuou sua aventura contente.'),
('duck_4','Logo o sol apareceu e um lindo arco-íris surgiu sobre a água.'),
('duck_5','Pipo voltou para sua família contando tudo o que havia descoberto naquele dia.'),
('monkey_1','Mico era um macaquinho que adorava subir nas árvores da floresta.'),
('monkey_2','Um dia ele viu uma fruta madura bem no alto de um galho distante.'),
('monkey_3','Mico balançou de galho em galho, sempre segurando firme antes de avançar.'),
('monkey_4','Quando chegou à fruta, encontrou outro macaquinho com fome e decidiu dividir.'),
('monkey_5','Os dois comeram juntos e depois continuaram pulando e brincando pela floresta.'),
]
for k,t in stories: PHRASES['story_'+k]=t

async def neural(key,text,max_attempts=6):
    mp3=OUT/(key+'.mp3'); wav=OUT/(key+'.wav')
    import edge_tts
    for attempt in range(1,max_attempts+1):
        try:
            mp3.unlink(missing_ok=True)
            c=edge_tts.Communicate(text,VOICE,rate='-12%',volume='+2%')
            await c.save(str(mp3))
            if not mp3.exists() or mp3.stat().st_size < 500:
                raise RuntimeError('TTS returned an empty/invalid MP3')
            subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(mp3),'-ac','2','-ar','44100','-af','silenceremove=start_periods=1:start_silence=0.04:start_threshold=-48dB,loudnorm=I=-18:TP=-2:LRA=6,afade=t=in:st=0:d=0.02,areverse,afade=t=in:st=0:d=0.03,areverse',str(wav)],check=True)
            mp3.unlink(missing_ok=True)
            if not wav.exists() or wav.stat().st_size < 1000:
                raise RuntimeError('TTS WAV conversion failed')
            print(f'Neural TTS OK: {key} (attempt {attempt})')
            return True
        except Exception as e:
            mp3.unlink(missing_ok=True)
            wav.unlink(missing_ok=True)
            print(f'Neural TTS attempt {attempt}/{max_attempts} failed for {key}: {e}')
            if attempt < max_attempts:
                # Edge/Bing occasionally rejects bursts from CI. Back off before retrying.
                await asyncio.sleep(min(20, 2 + attempt * 3))
    return False

async def generate_all():
    # Generate sequentially. The previous build launched several WebSocket
    # syntheses in parallel and Bing rejected one with HTTP 200/Invalid response.
    # Sequential generation plus retry/backoff is slower but substantially more
    # reliable for release builds and preserves the neural pt-BR voice.
    failures=[]
    total=len(PHRASES)
    for idx,(k,t) in enumerate(PHRASES.items(),1):
        wav=OUT/(k+'.wav')
        if wav.exists() and wav.stat().st_size >= 1000:
            print(f'[{idx}/{total}] Existing neural audio OK: {k}')
            continue
        print(f'[{idx}/{total}] Generating neural audio: {k}')
        ok=await neural(k,t)
        if not ok:
            failures.append(k)
        # Small spacing between successful requests also reduces service throttling.
        await asyncio.sleep(0.35)
    if failures:
        raise RuntimeError('Neural pt-BR TTS failed after retries for: '+', '.join(failures))

def save_wave(name, samples, sr=44100):
    path=OUT/(name+'.wav')
    mx=max(1e-6,max(abs(x) for x in samples)); scale=0.82/mx
    with wave.open(str(path),'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        data=bytearray()
        for x in samples:
            v=max(-1,min(1,x*scale)); data += struct.pack('<h',int(v*32767))
        w.writeframes(data)

def env(t,d,a=.02,r=.25):
    if t<a: return t/a
    if t>d-r: return max(0,(d-t)/r)
    return 1.0

def tone_sweep(d,f0,f1,harm=1.0,noise=0.0,amp=1.0,sr=44100):
    out=[]; phase=0.0; n=int(d*sr)
    for i in range(n):
        t=i/sr; f=f0+(f1-f0)*(t/d); phase+=2*math.pi*f/sr
        v=math.sin(phase)+0.35*math.sin(2*phase)*harm+0.15*math.sin(3*phase)*harm
        v += noise*random.uniform(-1,1)
        out.append(v*env(t,d)*amp)
    return out

def silence(d,sr=44100): return [0.0]*int(d*sr)
def concat(*parts):
    out=[]
    for p in parts: out.extend(p)
    return out

def sfx():
    save_wave('click', tone_sweep(.09,700,1100,.3,.02,.5))
    save_wave('success', concat(tone_sweep(.16,520,780,.4,0,.6),tone_sweep(.20,780,1050,.4,0,.7),tone_sweep(.25,1050,1320,.4,0,.8)))
    save_wave('pop', tone_sweep(.13,350,900,.2,.02,.5))
    save_wave('puzzle_snap', concat(tone_sweep(.08,520,760,.2,0,.45), tone_sweep(.10,760,980,.2,0,.5)))
    save_wave('page_turn', tone_sweep(.28,200,120,.1,.4,.4))
    # aliases for animals already synthesized
    # Gentle looping background music (simple major pentatonic glockenspiel-like bed).
    sr=44100; dur=32.0; n=int(sr*dur); music=[0.0]*n
    notes=[261.63,329.63,392.00,523.25,392.00,329.63,293.66,349.23,440.00,587.33,440.00,349.23]
    step=0.5
    for j,f in enumerate(notes*6):
        start=int(j*step*sr)
        if start>=n: break
        length=int(.42*sr)
        for i in range(min(length,n-start)):
            t=i/sr; e=math.exp(-4.2*t)
            v=(math.sin(2*math.pi*f*t)+0.28*math.sin(4*math.pi*f*t))*e*0.14
            music[start+i]+=v
    # soft sustained pad
    chords=[(130.81,164.81,196.00),(146.83,174.61,220.00),(130.81,164.81,196.00),(110.00,146.83,164.81)]
    for cidx,ch in enumerate(chords):
        start=int(cidx*8*sr); length=min(int(8*sr),n-start)
        for i in range(length):
            t=i/sr; e=min(1,t/.8)*min(1,(8-t)/.8)
            music[start+i]+=sum(math.sin(2*math.pi*f*t) for f in ch)*0.018*max(0,e)
    save_wave('music', music, sr)


REAL_SOUNDS={
 'snd_lion':('Lion raring-sound1TamilNadu178.ogg',0.0,3.4,'Public domain — Wikimedia Commons, author தகவலுழவன்'),
 'snd_elephant':('Elephant voice - trumpeting.ogg',0.0,1.4,'CC0 — Wikimedia Commons, author தகவலுழவன்'),
 'snd_dog':('Barking of a dog.ogg',0.0,2.5,'CC BY-SA 3.0 — Wikimedia Commons, author Amada44'),
 'snd_cow':('Single Cow Moo.ogg',0.0,3.7,'GFDL/CC — Wikimedia Commons, author MichaeltheFox8621'),
 'snd_duck':('Ducks snatching.ogg',0.0,3.2,'CC0 — Wikimedia Commons, author Bert76'),
 'snd_bear':('Bear growl.ogg',0.0,3.2,'CC BY 3.0/GFDL — Wikimedia Commons, author Shizhao'),
 'snd_frog':('Single Frog Croak.oga',0.0,3.8,'CC BY-SA 4.0 — Wikimedia Commons, author MichaeltheFox8621'),
 'snd_monkey':('Howler monkey.ogg',0.0,3.2,'Free media — Wikimedia Commons, author David O’Hara'),
 'snd_bird':('Troglodytes troglodytes chirp.ogg',0.0,0.7,'Free media — Wikimedia Commons, author Amada44'),
 'snd_giraffe':('Giraffe snort.oga',0.0,1.0,'Free media — Wikimedia Commons; real giraffe vocalization'),
}

def commons_direct_url(filename):
    # Bypass Special:Redirect, which returned HTTP 403 in GitHub Actions.
    # Wikimedia's upload path is deterministic from the MD5 of the UTF-8 filename.
    import hashlib
    digest=hashlib.md5(filename.replace(' ','_').encode('utf-8')).hexdigest()
    quoted=urllib.parse.quote(filename.replace(' ','_'), safe="()_',.-")
    return f'https://upload.wikimedia.org/wikipedia/commons/{digest[0]}/{digest[:2]}/{quoted}'

def download_with_retry(url,dst,attempts=4):
    import time
    last=None
    for attempt in range(1,attempts+1):
        try:
            req=urllib.request.Request(url,headers={
                'User-Agent':'MundoTouch/3.1 (+https://github.com/iagoribeiroptu-cpu/-MundoTouch)',
                'Accept':'audio/ogg,audio/*;q=0.9,*/*;q=0.1',
            })
            with urllib.request.urlopen(req,timeout=45) as r, open(dst,'wb') as f:
                while True:
                    chunk=r.read(1024*128)
                    if not chunk: break
                    f.write(chunk)
            if Path(dst).stat().st_size < 3000:
                raise RuntimeError('download too small')
            return
        except Exception as exc:
            last=exc
            Path(dst).unlink(missing_ok=True)
            print(f'  attempt {attempt}/{attempts} failed: {exc}')
            if attempt<attempts: time.sleep(2*attempt)
    raise RuntimeError(f'Falha ao baixar gravação real: {url} — {last}')

def real_sounds():
    credits=['MundoTouch 3.1 — gravações reais de animais','Origem: Wikimedia Commons. Downloads diretos de upload.wikimedia.org; sem Special:Redirect.','']
    for key,(filename,start,dur,credit) in REAL_SOUNDS.items():
        url=commons_direct_url(filename)
        src=OUT/(key+'_source')
        print('Downloading real animal sound:',filename)
        print('  source:',url)
        download_with_retry(url,src)
        dst=OUT/(key+'.wav')
        fade_out=max(.1,dur-.08)
        subprocess.run(['ffmpeg','-loglevel','error','-y','-ss',str(start),'-t',str(dur),'-i',str(src),'-ac','2','-ar','44100','-af',f'highpass=f=45,lowpass=f=12000,loudnorm=I=-18:TP=-2:LRA=7,afade=t=in:st=0:d=0.02,afade=t=out:st={fade_out}:d=0.08',str(dst)],check=True)
        src.unlink(missing_ok=True)
        if not dst.exists() or dst.stat().st_size<4000: raise RuntimeError('Falha no som real: '+key)
        credits.append(f'{key}: {filename} — {credit} — {url}')
    # Turtle/fish deliberately have no fabricated electronic animal noise.
    # Their spoken names remain; a real recording is only used where a reliable vocalization exists.
    Path('ANIMAL_AUDIO_CREDITS.txt').write_text('\n'.join(credits),encoding='utf-8')

if __name__=='__main__':
    asyncio.run(generate_all()); sfx(); real_sounds()
    import json
    report=[]
    for key,text in sorted(PHRASES.items()):
        f=OUT/(key+'.wav')
        if not f.exists() or f.stat().st_size < 1000: raise RuntimeError('Invalid audio: '+key)
        with wave.open(str(f),'rb') as w: dur=w.getnframes()/float(w.getframerate()); sr=w.getframerate(); ch=w.getnchannels()
        if dur < 0.08 or dur > 25: raise RuntimeError(f'Abnormal duration {key}: {dur:.2f}s')
        report.append({'id':key,'text':text,'file':f.name,'duration_s':round(dur,2),'sample_rate':sr,'channels':ch,'status':'OK'})
    Path('audio_qa_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Audio files:',len(list(OUT.glob('*.wav')))); print('QA voice entries:',len(report))

#include <switch.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_ttf.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <map>
#include <random>
#include <string>
#include <vector>

static constexpr int W=1280, H=720;

struct Tex { SDL_Texture* t=nullptr; int w=0,h=0; };
struct Particle { float x,y,vx,vy,life; SDL_Color c; };
struct Hotspot { SDL_Rect r; std::string key,label; };

static bool inRect(int x,int y,const SDL_Rect& r){ return x>=r.x && y>=r.y && x<r.x+r.w && y<r.y+r.h; }
static SDL_Color rgba(Uint8 r,Uint8 g,Uint8 b,Uint8 a=255){ return SDL_Color{r,g,b,a}; }

class FontBook {
public:
    bool init(){
        if(R_FAILED(plInitialize(PlServiceType_User))) return false;
        plOk=true;
        if(R_FAILED(plGetSharedFontByType(&fontData,PlSharedFontType_Standard))) return false;
        return true;
    }
    TTF_Font* get(int size){
        auto it=fonts.find(size); if(it!=fonts.end()) return it->second;
        SDL_RWops* rw=SDL_RWFromConstMem(fontData.address,fontData.size);
        if(!rw) return nullptr;
        TTF_Font* f=TTF_OpenFontRW(rw,1,size);
        if(f){ TTF_SetFontHinting(f,TTF_HINTING_LIGHT); fonts[size]=f; }
        return f;
    }
    ~FontBook(){ for(auto& kv:fonts) TTF_CloseFont(kv.second); if(plOk) plExit(); }
private:
    bool plOk=false; PlFontData fontData{}; std::map<int,TTF_Font*> fonts;
};

class Audio {
public:
    bool init(){
        if(Mix_OpenAudio(22050,AUDIO_S16LSB,1,1024)<0) return false;
        Mix_AllocateChannels(8); Mix_Volume(0,118); Mix_Volume(1,96);
        music=Mix_LoadMUS("romfs:/audio/music.wav");
        if(music){ Mix_VolumeMusic(24); Mix_PlayMusic(music,-1); }
        return true;
    }
    Mix_Chunk* chunk(const std::string& key){
        auto it=cache.find(key); if(it!=cache.end()) return it->second;
        std::string p="romfs:/audio/"+key+".wav"; Mix_Chunk* c=Mix_LoadWAV(p.c_str());
        if(c) cache[key]=c; return c;
    }
    void voice(const std::string& k){ if(!enabled) return; pending.clear(); if(auto*c=chunk(k)){Mix_HaltChannel(0); Mix_VolumeMusic(7); ducked=true; Mix_PlayChannel(0,c,0);} }
    void sfx(const std::string& k){ if(!enabled) return; if(auto*c=chunk(k)) Mix_PlayChannel(1,c,0); }
    void animal(const std::string& voiceKey,const std::string& soundKey){ if(!enabled) return; pending=soundKey; if(auto*c=chunk(voiceKey)){Mix_HaltChannel(0); Mix_VolumeMusic(7); ducked=true; Mix_PlayChannel(0,c,0);} else { sfx(soundKey); pending.clear(); } }
    void update(){ if(!enabled) return; if(ducked && !Mix_Playing(0)){ Mix_VolumeMusic(24); ducked=false; } if(!pending.empty() && !Mix_Playing(0)){ auto k=pending; pending.clear(); sfx(k); } }
    void toggle(){ enabled=!enabled; pending.clear(); ducked=false; if(enabled){ if(music){ Mix_VolumeMusic(24); Mix_ResumeMusic(); } } else {Mix_HaltChannel(-1); Mix_PauseMusic();} }
    bool isEnabled()const{return enabled;}
    bool voicePlaying()const{return enabled && Mix_Playing(0)!=0;}
    ~Audio(){ if(music) Mix_FreeMusic(music); for(auto&kv:cache) Mix_FreeChunk(kv.second); Mix_CloseAudio(); }
private:
    bool enabled=true, ducked=false; Mix_Music* music=nullptr; std::map<std::string,Mix_Chunk*> cache; std::string pending;
};

enum class Screen{HOME,MORE,ANIMALS,PUZZLE,COLOR,DRAW,LETTERS,NUMBERS,HUNT,STORIES,SHAPES,VEHICLES,FRUITS};

class Game {
public:
    bool init(){
        if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO|SDL_INIT_GAMECONTROLLER)<0) return false;
        IMG_Init(IMG_INIT_JPG|IMG_INIT_PNG); if(TTF_Init()<0) return false;
        romfsInit(); SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY,"1");
        win=SDL_CreateWindow("MundoTouch 3.0",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,W,H,SDL_WINDOW_SHOWN);
        if(!win) return false;
        ren=SDL_CreateRenderer(win,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);
        if(!ren) ren=SDL_CreateRenderer(win,-1,SDL_RENDERER_SOFTWARE);
        if(!ren) return false;
        SDL_RenderSetLogicalSize(ren,W,H); SDL_SetRenderDrawBlendMode(ren,SDL_BLENDMODE_BLEND);
        fonts.init(); audio.init();
        padConfigureInput(1,HidNpadStyleSet_NpadStandard); padInitializeDefault(&pad);
        rng.seed((unsigned)armGetSystemTick());
        loadAssets(); initCanvases(); initData();
        setScreen(Screen::HOME,false); audio.voice("welcome");
        return true;
    }
    void loop(){
        Uint32 last=SDL_GetTicks();
        while(running && appletMainLoop()){
            Uint32 now=SDL_GetTicks(); float dt=std::min(0.05f,(now-last)/1000.0f); last=now;
            events(); padUpdate(&pad); auto down=padGetButtonsDown(&pad);
            if(down&HidNpadButton_Plus) running=false;
            if(down&HidNpadButton_B) back();
            audio.update(); update(dt,now); render(now); SDL_RenderPresent(ren);
        }
    }
    ~Game(){
        clearUndo(drawUndo); clearUndo(colorUndo);
        if(drawTex)SDL_DestroyTexture(drawTex); if(drawSurf)SDL_FreeSurface(drawSurf);
        if(colorTex)SDL_DestroyTexture(colorTex); if(colorSurf)SDL_FreeSurface(colorSurf); if(lineSurf)SDL_FreeSurface(lineSurf); if(lineTex)SDL_DestroyTexture(lineTex);
        for(auto&kv:textures) if(kv.second.t) SDL_DestroyTexture(kv.second.t);
        if(ren)SDL_DestroyRenderer(ren); if(win)SDL_DestroyWindow(win); romfsExit(); TTF_Quit(); IMG_Quit(); SDL_Quit();
    }
private:
    SDL_Window* win=nullptr; SDL_Renderer* ren=nullptr; FontBook fonts; Audio audio; PadState pad{};
    bool running=true, pointer=false, touchSeen=false; int px=0,py=0,lastx=0,lasty=0; Uint32 lastPointerMs=0;
    Screen screen=Screen::HOME; Uint8 fade=0; std::map<std::string,Tex> textures; std::mt19937 rng;
    std::vector<Particle> particles;

    // animal explorer
    struct Animal {std::string name,voice,sound,tex; SDL_Rect src;}; std::vector<Animal> animals; int animalIndex=0;
    // puzzle
    int puzzleRows=2,puzzleCols=2,puzzleScene=0,puzzleSelected=-1; std::vector<int> puzzleOrder; bool puzzleSolved=false;
    std::array<std::string,4> puzzleScenes{{"story_lion_1","story_elephant_1","story_turtle_1","animals"}};
    // draw/color
    SDL_Surface* drawSurf=nullptr; SDL_Texture* drawTex=nullptr; SDL_Surface* colorSurf=nullptr; SDL_Texture* colorTex=nullptr; SDL_Surface* lineSurf=nullptr; SDL_Texture* lineTex=nullptr;
    int drawColor=0,colorColor=2,drawSize=12,colorSize=18,colorTool=0,drawTool=0,colorPage=0; // tools:0 brush,1 chalk/marker,2 bucket,3 eraser
    std::vector<SDL_Surface*> drawUndo,colorUndo; std::array<SDL_Color,12> palette{{rgba(244,67,54),rgba(255,152,0),rgba(255,215,45),rgba(76,190,70),rgba(40,170,235),rgba(30,90,220),rgba(145,65,220),rgba(240,80,155),rgba(135,75,40),rgba(35,35,35),rgba(255,255,255),rgba(30,200,175)}};
    std::array<std::string,4> linePages{{"line_lion.png","line_elephant.png","line_giraffe.png","line_turtle.png"}};
    // letters/numbers
    int letterIndex=0,numberIndex=3;
    std::array<const char*,26> letterWords{{"ABELHA","BOLA","CACHORRO","DADO","ELEFANTE","FLOR","GATO","HIPOPOTAMO","ILHA","JACARE","KIWI","LEAO","MACACO","NAVIO","OVELHA","PATO","QUEIJO","RATO","SAPO","TARTARUGA","UVA","VACA","WAFFLE","XILOFONE","YAK","ZEBRA"}};
    // hunt
    std::vector<Hotspot> hunts; std::vector<int> huntOrder; int huntPos=0,huntFound=0; Uint32 nextHuntAt=0; bool huntAwaitFirst=false;
    // stories
    int story=0,storyPage=0; bool storyAwaitFirst=false; std::array<const char*,3> storyNames{{"O LEAOZINHO E A FLORESTA","O ELEFANTINHO CORAJOSO","A TARTARUGUINHA E O MAR"}};
    // simple modules
    int selectedShape=-1,selectedVehicle=-1,selectedFruit=-1;

    Tex load(const std::string& key,const std::string& path){
        SDL_Surface*s=IMG_Load(path.c_str()); if(!s) return {};
        Tex x; x.w=s->w;x.h=s->h; x.t=SDL_CreateTextureFromSurface(ren,s); SDL_FreeSurface(s); textures[key]=x; return x;
    }
    void loadAssets(){
        const char* names[]={"home","animals","puzzle","hidden","stories","letters","story_lion_1","story_lion_2","story_lion_3","story_elephant_1","story_elephant_2","story_elephant_3","story_turtle_1","story_turtle_2","story_turtle_3"};
        for(auto n:names){ std::string ext=".jpg"; load(n,"romfs:/assets/"+std::string(n)+ext); }
    }
    void initCanvases(){
        drawSurf=SDL_CreateRGBSurfaceWithFormat(0,820,520,32,SDL_PIXELFORMAT_RGBA32); SDL_FillRect(drawSurf,nullptr,SDL_MapRGBA(drawSurf->format,255,255,255,255)); refreshDraw();
        loadColorPage(0);
    }
    void initData(){
        animals={
          {"ELEFANTE","animal_elefante","snd_elephant","animals",{65,170,350,230}},
          {"LEAO","animal_leao","snd_lion","animals",{450,160,245,235}},
          {"GIRAFA","animal_girafa","snd_giraffe","animals",{720,160,255,235}},
          {"MACACO","animal_macaco","snd_monkey","animals",{995,175,240,225}},
          {"VACA","animal_vaca","snd_cow","animals",{500,420,245,170}},
          {"PATO","animal_pato","snd_duck","animals",{850,420,235,170}},
          {"CACHORRO","animal_cachorro","snd_dog","hidden",{1010,410,150,165}},
          {"URSO","animal_urso","snd_bear","hidden",{10,385,245,190}},
          {"SAPO","animal_sapo","snd_frog","hidden",{250,590,120,100}},
          {"PASSARINHO","animal_passaro","snd_bird","stories",{780,145,150,120}},
          {"TARTARUGA","animal_tartaruga","snd_turtle","story_turtle_1",{360,80,530,500}},
          {"PEIXE","animal_peixe","snd_fish","story_turtle_1",{850,250,260,210}}
        };
        hunts={
          {{330,490,100,90},"bola","BOLA"},{{40,390,220,190},"urso","URSINHO"},{{840,465,135,100},"carro","CARRO"},{{420,455,150,125},"bicicleta","BICICLETA"},{{420,535,80,75},"maca","MACA"},{{560,520,125,80},"banana","BANANA"},{{690,320,125,210},"girafa","GIRAFA"},{{940,530,115,80},"pato","PATO"},{{955,470,90,85},"numero3","NUMERO 3"},{{1070,515,90,90},"letraA","LETRA A"},{{1180,535,90,85},"laranja","LARANJA"},{{420,310,115,120},"macaco","MACACO"},{{300,405,105,90},"mochila","MOCHILA"},{{790,335,95,100},"pipa","PIPA"},{{255,585,110,95},"sapo","SAPO"}
        };
        huntOrder.resize(hunts.size()); for(size_t i=0;i<hunts.size();++i)huntOrder[i]=i; std::shuffle(huntOrder.begin(),huntOrder.end(),rng);
        newPuzzle();
    }
    void clearUndo(std::vector<SDL_Surface*>&v){for(auto*s:v)SDL_FreeSurface(s);v.clear();}
    void pushUndo(SDL_Surface*s,std::vector<SDL_Surface*>&v){ if(v.size()>=5){SDL_FreeSurface(v.front());v.erase(v.begin());} v.push_back(SDL_ConvertSurface(s,s->format,0)); }
    void undo(SDL_Surface*&s,SDL_Texture*&t,std::vector<SDL_Surface*>&v){ if(v.empty())return; SDL_FreeSurface(s);s=v.back();v.pop_back(); if(!t)t=SDL_CreateTexture(ren,SDL_PIXELFORMAT_RGBA32,SDL_TEXTUREACCESS_STREAMING,s->w,s->h); SDL_UpdateTexture(t,nullptr,s->pixels,s->pitch); }
    void refreshDraw(){ if(!drawTex)drawTex=SDL_CreateTexture(ren,SDL_PIXELFORMAT_RGBA32,SDL_TEXTUREACCESS_STREAMING,drawSurf->w,drawSurf->h); SDL_UpdateTexture(drawTex,nullptr,drawSurf->pixels,drawSurf->pitch); }
    void refreshColor(){ if(!colorTex)colorTex=SDL_CreateTexture(ren,SDL_PIXELFORMAT_RGBA32,SDL_TEXTUREACCESS_STREAMING,colorSurf->w,colorSurf->h); SDL_UpdateTexture(colorTex,nullptr,colorSurf->pixels,colorSurf->pitch); }
    void loadColorPage(int idx){
        colorPage=(idx+4)%4; if(colorSurf)SDL_FreeSurface(colorSurf); if(lineSurf)SDL_FreeSurface(lineSurf); if(lineTex)SDL_DestroyTexture(lineTex);
        std::string path="romfs:/assets/"+linePages[colorPage]; SDL_Surface* raw=IMG_Load(path.c_str());
        if(!raw){ lineSurf=SDL_CreateRGBSurfaceWithFormat(0,900,520,32,SDL_PIXELFORMAT_RGBA32); SDL_FillRect(lineSurf,nullptr,SDL_MapRGB(lineSurf->format,255,255,255)); }
        else { lineSurf=SDL_ConvertSurfaceFormat(raw,SDL_PIXELFORMAT_RGBA32,0); SDL_FreeSurface(raw); }
        colorSurf=SDL_ConvertSurface(lineSurf,lineSurf->format,0);
        // Keep the original black outlines crisp while allowing paint below them to remain visible.
        SDL_SetColorKey(lineSurf,SDL_TRUE,SDL_MapRGB(lineSurf->format,255,255,255));
        lineTex=SDL_CreateTextureFromSurface(ren,lineSurf); SDL_SetTextureBlendMode(lineTex,SDL_BLENDMODE_BLEND); refreshColor(); clearUndo(colorUndo);
    }
    void setScreen(Screen s,bool speak=true){ screen=s; fade=180; pointer=false; if(!speak)return; audio.sfx("click");
        switch(s){case Screen::HOME:audio.voice("welcome");break;case Screen::MORE:audio.voice("home_more");break;case Screen::ANIMALS:audio.voice("animals_intro");break;case Screen::PUZZLE:audio.voice("puzzle_intro");break;case Screen::COLOR:audio.voice("color_intro");break;case Screen::DRAW:audio.voice("draw_intro");break;case Screen::LETTERS:audio.voice("letters_intro");break;case Screen::NUMBERS:audio.voice("numbers_intro");break;case Screen::HUNT:resetHunt();huntAwaitFirst=true;audio.voice("hunt_intro");break;case Screen::STORIES:storyAwaitFirst=true;audio.voice("stories_intro");break;case Screen::SHAPES:audio.voice("shapes_intro");break;case Screen::VEHICLES:audio.voice("vehicles_intro");break;case Screen::FRUITS:audio.voice("fruits_intro");break;}
    }
    void back(){ if(screen==Screen::HOME){running=false;return;} if(screen==Screen::MORE){setScreen(Screen::HOME);return;} setScreen(Screen::HOME); }

    void events(){ SDL_Event e; while(SDL_PollEvent(&e)){ if(e.type==SDL_QUIT){running=false;continue;} if(e.type==SDL_FINGERDOWN){touchSeen=true; int x=int(e.tfinger.x*W),y=int(e.tfinger.y*H); pointerDown(x,y);}
        else if(e.type==SDL_FINGERMOTION && pointer){pointerMove(int(e.tfinger.x*W),int(e.tfinger.y*H));}
        else if(e.type==SDL_FINGERUP){pointerUp(int(e.tfinger.x*W),int(e.tfinger.y*H));}
        else if(e.type==SDL_MOUSEBUTTONDOWN && e.button.button==SDL_BUTTON_LEFT){ if(SDL_GetTicks()-lastPointerMs>60)pointerDown(e.button.x,e.button.y); }
        else if(e.type==SDL_MOUSEMOTION && pointer){pointerMove(e.motion.x,e.motion.y);}
        else if(e.type==SDL_MOUSEBUTTONUP && e.button.button==SDL_BUTTON_LEFT){pointerUp(e.button.x,e.button.y);} }
    }
    void pointerDown(int x,int y){ lastPointerMs=SDL_GetTicks(); pointer=true;px=lastx=x;py=lasty=y;
        if(screen!=Screen::HOME && screen!=Screen::MORE && x<120 && y<100){back();pointer=false;return;}
        if(screen==Screen::COLOR){ colorDown(x,y); return; }
        if(screen==Screen::DRAW){ drawDown(x,y); return; }
        if(screen==Screen::PUZZLE){ puzzleDown(x,y); return; }
    }
    void pointerMove(int x,int y){ if(!pointer)return; if(screen==Screen::COLOR)colorMove(x,y); else if(screen==Screen::DRAW)drawMove(x,y); lastx=x;lasty=y; }
    void pointerUp(int x,int y){ if(!pointer)return; pointer=false;
        if(screen==Screen::PUZZLE){ puzzleUp(x,y); return; }
        if(screen==Screen::COLOR||screen==Screen::DRAW) return;
        switch(screen){case Screen::HOME:homeTap(x,y);break;case Screen::MORE:moreTap(x,y);break;case Screen::ANIMALS:animalTap(x,y);break;case Screen::LETTERS:letterTap(x,y);break;case Screen::NUMBERS:numberTap(x,y);break;case Screen::HUNT:huntTap(x,y);break;case Screen::STORIES:storyTap(x,y);break;case Screen::SHAPES:shapeTap(x,y);break;case Screen::VEHICLES:vehicleTap(x,y);break;case Screen::FRUITS:fruitTap(x,y);break;default:break;}
    }

    void homeTap(int x,int y){
        if(inRect(x,y,{245,250,265,145}))setScreen(Screen::ANIMALS);
        else if(inRect(x,y,{505,250,265,145}))setScreen(Screen::COLOR);
        else if(inRect(x,y,{775,250,270,145}))setScreen(Screen::PUZZLE);
        else if(inRect(x,y,{245,395,265,150}))setScreen(Screen::HUNT);
        else if(inRect(x,y,{505,395,265,150}))setScreen(Screen::STORIES);
        else if(inRect(x,y,{775,395,270,150}))setScreen(Screen::LETTERS);
        else if(inRect(x,y,{455,585,390,120}))setScreen(Screen::MORE);
        else if(inRect(x,y,{1020,10,130,70}))audio.toggle();
    }
    void moreTap(int x,int y){
        std::array<SDL_Rect,6> r{{{160,190,290,150},{495,190,290,150},{830,190,290,150},{160,390,290,150},{495,390,290,150},{830,390,290,150}}};
        if(inRect(x,y,r[0]))setScreen(Screen::DRAW); else if(inRect(x,y,r[1]))setScreen(Screen::SHAPES); else if(inRect(x,y,r[2]))setScreen(Screen::VEHICLES); else if(inRect(x,y,r[3]))setScreen(Screen::FRUITS); else if(inRect(x,y,r[4]))setScreen(Screen::NUMBERS); else if(inRect(x,y,r[5]))setScreen(Screen::HOME);
    }
    void animalTap(int x,int y){
        // Fixed visible animals on the background.
        if(inRect(x,y,{440,170,270,240}))animalIndex=1; else if(inRect(x,y,{710,170,270,240}))animalIndex=2; else if(inRect(x,y,{990,170,270,240}))animalIndex=3; else if(inRect(x,y,{470,410,300,190}))animalIndex=4; else if(inRect(x,y,{820,410,300,190}))animalIndex=5; else if(inRect(x,y,{420,610,430,100}))animalIndex=(animalIndex+1)%animals.size();
        else if(inRect(x,y,{40,185,390,410})){} else return;
        auto&a=animals[animalIndex]; audio.animal(a.voice,a.sound); spawn(640,340,25);
    }
    void letterTap(int x,int y){ if(x<360 && y>585)letterIndex=(letterIndex+25)%26; else if(x>900 && y>585)letterIndex=(letterIndex+1)%26; else if(y>575){int i=(x-300)/65;if(i>=0&&i<7)letterIndex=(letterIndex/7)*7+i,letterIndex=std::min(letterIndex,25);} else if(inRect(x,y,{250,170,430,390})){} else return; audio.voice(keyLetter()); }
    std::string keyLetter()const{ char b[32]; std::snprintf(b,sizeof(b),"letter_%02d",letterIndex); return b; }
    void numberTap(int x,int y){ if(y<=580)return; if(x>=250 && x<1030){int i=(x-250)/78+1;if(i>=1&&i<=10)numberIndex=i;else return;} else if(x<250)numberIndex=numberIndex<=1?10:numberIndex-1; else numberIndex=numberIndex>=10?1:numberIndex+1; audio.voice(keyNumber()); }
    std::string keyNumber()const{ char b[32];std::snprintf(b,sizeof(b),"number_%02d",numberIndex);return b; }
    void resetHunt(){ huntPos=0;huntFound=0;std::shuffle(huntOrder.begin(),huntOrder.end(),rng);nextHuntAt=0;huntAwaitFirst=false; }
    void playHuntPrompt(){ audio.voice("hunt_"+hunts[huntOrder[huntPos]].key); }
    void huntTap(int x,int y){ if(nextHuntAt)return; int idx=huntOrder[huntPos]; if(inRect(x,y,hunts[idx].r)){huntFound++;spawn(x,y,45);audio.sfx("success");nextHuntAt=SDL_GetTicks()+850;} else audio.voice("retry"); }
    void storyTap(int x,int y){
        if(y>555 && x>400 && x<860){int s=(x-410)/155;if(s>=0&&s<3){story=s;storyPage=0;playStory();return;}}
        if(x<410&&y>540){storyPage=(storyPage+2)%3;audio.sfx("page_turn");playStory();}
        else if(x>870&&y>540){storyPage=(storyPage+1)%3;audio.sfx("page_turn");playStory();}
        else if(inRect(x,y,{260,130,760,410})){std::string fx; if(story==0)fx=storyPage==0?"snd_lion":storyPage==1?"snd_bird":"snd_frog"; else if(story==1)fx=storyPage==0?"snd_elephant":storyPage==1?"snd_duck":"success"; else fx=storyPage==0?"snd_turtle":storyPage==1?"snd_fish":"success"; audio.animal(storyKey(),fx);}
    }
    std::string storyKey()const{ static const char* n[]={"lion","elephant","turtle"}; return "story_"+std::string(n[story])+"_"+std::to_string(storyPage+1); }
    void playStory(){audio.voice(storyKey());}
    void shapeTap(int x,int y){int c=(x-170)/310,r=(y-210)/190;if(c<0||c>2||r<0||r>1)return;int i=r*3+c;static const char*k[]={"circle","square","triangle","star","heart","diamond"};selectedShape=i;audio.voice("shape_"+std::string(k[i]));spawn(x,y,20);}
    void vehicleTap(int x,int y){int c=(x-115)/265,r=(y-220)/190;if(c<0||c>3||r<0||r>1)return;int i=r*4+c;static const char*k[]={"car","bus","truck","plane","train","boat","bike","helicopter"};selectedVehicle=i;audio.voice("vehicle_"+std::string(k[i]));spawn(x,y,15);}
    void fruitTap(int x,int y){int c=(x-115)/265,r=(y-220)/190;if(c<0||c>3||r<0||r>1)return;int i=r*4+c;static const char*k[]={"apple","banana","orange","grape","carrot","broccoli","strawberry","pear"};selectedFruit=i;audio.voice("fruit_"+std::string(k[i]));spawn(x,y,15);}

    void newPuzzle(){ int n=puzzleRows*puzzleCols; puzzleOrder.resize(n);for(int i=0;i<n;++i)puzzleOrder[i]=i; do{std::shuffle(puzzleOrder.begin(),puzzleOrder.end(),rng);}while(std::is_sorted(puzzleOrder.begin(),puzzleOrder.end()));puzzleSolved=false;puzzleSelected=-1; }
    SDL_Rect puzzleBoard()const{return {455,155,440,440};}
    int puzzleSlotAt(int x,int y)const{SDL_Rect b=puzzleBoard();if(!inRect(x,y,b))return -1;int cw=b.w/puzzleCols,ch=b.h/puzzleRows;int c=(x-b.x)/cw,r=(y-b.y)/ch;return r*puzzleCols+c;}
    void puzzleDown(int x,int y){
        if(x<120&&y<100){back();pointer=false;return;}
        // difficulty buttons
        if(inRect(x,y,{120,195,145,105})){puzzleRows=1;puzzleCols=2;newPuzzle();pointer=false;return;}
        if(inRect(x,y,{280,195,145,105})){puzzleRows=2;puzzleCols=2;newPuzzle();pointer=false;return;}
        if(inRect(x,y,{120,305,145,105})){puzzleRows=2;puzzleCols=3;newPuzzle();pointer=false;return;}
        if(inRect(x,y,{280,305,145,105})){puzzleRows=3;puzzleCols=3;newPuzzle();pointer=false;return;}
        if(inRect(x,y,{1050,570,180,70})){puzzleRows=3;puzzleCols=4;newPuzzle();pointer=false;return;}
        if(y>450&&x<430){int s=(x-65)/95;if(s>=0&&s<4){puzzleScene=s;newPuzzle();pointer=false;return;}}
        puzzleSelected=puzzleSlotAt(x,y); if(puzzleSelected>=0)audio.sfx("click");
    }
    void puzzleUp(int x,int y){if(puzzleSelected<0)return;int target=puzzleSlotAt(x,y);if(target>=0&&target!=puzzleSelected){std::swap(puzzleOrder[target],puzzleOrder[puzzleSelected]);audio.sfx("pop");}puzzleSelected=-1;bool ok=true;for(size_t i=0;i<puzzleOrder.size();++i)if(puzzleOrder[i]!=(int)i)ok=false;if(ok&&!puzzleSolved){puzzleSolved=true;audio.voice("puzzle_done");spawn(670,360,80);} }

    void colorDown(int x,int y){
        if(x<120&&y<100){back();pointer=false;return;}
        SDL_Rect cv{260,125,700,500};
        if(inRect(x,y,cv)){pushUndo(colorSurf,colorUndo); if(colorTool==2){flood(colorSurf,int((x-cv.x)*colorSurf->w/(float)cv.w),int((y-cv.y)*colorSurf->h/(float)cv.h),palette[colorColor]);refreshColor();pointer=false;} else {paintAt(colorSurf,int((x-cv.x)*colorSurf->w/(float)cv.w),int((y-cv.y)*colorSurf->h/(float)cv.h),colorTool==3?rgba(255,255,255):palette[colorColor],colorSize);refreshColor();}return;}
        // palette 3x4
        for(int r=0;r<4;++r)for(int c=0;c<3;++c){SDL_Rect q{1005+c*75,240+r*70,58,58};if(inRect(x,y,q)){colorColor=r*3+c;audio.sfx("click");pointer=false;return;}}
        if(inRect(x,y,{35,180,190,75}))colorTool=0; else if(inRect(x,y,{35,270,190,75}))colorTool=1; else if(inRect(x,y,{35,360,190,75}))colorTool=2; else if(inRect(x,y,{35,450,190,75}))colorTool=3; else if(inRect(x,y,{35,540,190,75}))undo(colorSurf,colorTex,colorUndo); else if(inRect(x,y,{990,580,80,70}))loadColorPage(colorPage-1); else if(inRect(x,y,{1160,580,80,70}))loadColorPage(colorPage+1); pointer=false;
    }
    void colorMove(int x,int y){SDL_Rect cv{260,125,700,500};if(!inRect(x,y,cv)||colorTool==2)return;int x1=int((lastx-cv.x)*colorSurf->w/(float)cv.w),y1=int((lasty-cv.y)*colorSurf->h/(float)cv.h),x2=int((x-cv.x)*colorSurf->w/(float)cv.w),y2=int((y-cv.y)*colorSurf->h/(float)cv.h);paintLine(colorSurf,x1,y1,x2,y2,colorTool==3?rgba(255,255,255):palette[colorColor],colorSize);refreshColor();}
    void drawDown(int x,int y){
        if(x<120&&y<100){back();pointer=false;return;} SDL_Rect cv{225,105,820,520};
        if(inRect(x,y,cv)){pushUndo(drawSurf,drawUndo);paintAt(drawSurf,x-cv.x,y-cv.y,drawTool==2?rgba(255,255,255):palette[drawColor],drawSize);refreshDraw();return;}
        for(int r=0;r<6;++r)for(int c=0;c<2;++c){SDL_Rect q{1080+c*70,155+r*70,55,55};if(inRect(x,y,q)){drawColor=r*2+c;drawTool=0;audio.sfx("click");pointer=false;return;}}
        if(inRect(x,y,{25,180,165,70})){drawTool=0;drawSize=9;} else if(inRect(x,y,{25,265,165,70})){drawTool=0;drawSize=18;} else if(inRect(x,y,{25,350,165,70})){drawTool=0;drawSize=30;} else if(inRect(x,y,{25,435,165,70})){drawTool=2;drawSize=22;} else if(inRect(x,y,{25,520,165,70}))undo(drawSurf,drawTex,drawUndo); else if(inRect(x,y,{1080,590,130,70})){pushUndo(drawSurf,drawUndo);SDL_FillRect(drawSurf,nullptr,SDL_MapRGBA(drawSurf->format,255,255,255,255));refreshDraw();} pointer=false;
    }
    void drawMove(int x,int y){SDL_Rect cv{225,105,820,520};if(!inRect(x,y,cv))return;paintLine(drawSurf,lastx-cv.x,lasty-cv.y,x-cv.x,y-cv.y,drawTool==2?rgba(255,255,255):palette[drawColor],drawSize);refreshDraw();}

    Uint32 getPixel(SDL_Surface*s,int x,int y){x=std::clamp(x,0,s->w-1);y=std::clamp(y,0,s->h-1);return ((Uint32*)((Uint8*)s->pixels+y*s->pitch))[x];}
    void setPixel(SDL_Surface*s,int x,int y,Uint32 p){if(x<0||y<0||x>=s->w||y>=s->h)return;((Uint32*)((Uint8*)s->pixels+y*s->pitch))[x]=p;}
    void paintAtLocked(SDL_Surface*s,int x,int y,Uint32 p,int rad){for(int yy=-rad;yy<=rad;++yy)for(int xx=-rad;xx<=rad;++xx)if(xx*xx+yy*yy<=rad*rad)setPixel(s,x+xx,y+yy,p);}
    void paintAt(SDL_Surface*s,int x,int y,SDL_Color c,int rad){SDL_LockSurface(s);Uint32 p=SDL_MapRGBA(s->format,c.r,c.g,c.b,255);paintAtLocked(s,x,y,p,rad);SDL_UnlockSurface(s);}
    void paintLine(SDL_Surface*s,int x1,int y1,int x2,int y2,SDL_Color c,int rad){int dx=x2-x1,dy=y2-y1,steps=std::max(1,std::max(std::abs(dx),std::abs(dy))/3);SDL_LockSurface(s);Uint32 p=SDL_MapRGBA(s->format,c.r,c.g,c.b,255);for(int i=0;i<=steps;++i){float t=i/(float)steps;paintAtLocked(s,int(x1+dx*t),int(y1+dy*t),p,rad);}SDL_UnlockSurface(s);}
    void flood(SDL_Surface*s,int sx,int sy,SDL_Color nc){ if(sx<0||sy<0||sx>=s->w||sy>=s->h)return;SDL_LockSurface(s);Uint32 old=getPixel(s,sx,sy),neu=SDL_MapRGBA(s->format,nc.r,nc.g,nc.b,255);if(old==neu){SDL_UnlockSurface(s);return;}Uint8 orr,org,orb,ora;SDL_GetRGBA(old,s->format,&orr,&org,&orb,&ora);if(orr<80&&org<80&&orb<80){SDL_UnlockSurface(s);return;}std::vector<std::pair<int,int>> st;st.reserve(50000);st.push_back({sx,sy});size_t cap=600000;while(!st.empty()&&cap--){auto [x,y]=st.back();st.pop_back();if(x<0||y<0||x>=s->w||y>=s->h)continue;Uint32 p=getPixel(s,x,y);Uint8 r,g,b,a;SDL_GetRGBA(p,s->format,&r,&g,&b,&a);int d=std::abs((int)r-orr)+std::abs((int)g-org)+std::abs((int)b-orb);if(d>45)continue;setPixel(s,x,y,neu);st.push_back({x+1,y});st.push_back({x-1,y});st.push_back({x,y+1});st.push_back({x,y-1});}SDL_UnlockSurface(s);}

    void update(float dt,Uint32 now){
        if(fade>0) fade=(Uint8)(fade>dt*600?fade-dt*600:0);
        for(auto&p:particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=160*dt;p.life-=dt;}particles.erase(std::remove_if(particles.begin(),particles.end(),[](auto&p){return p.life<=0;}),particles.end());
        if(screen==Screen::HUNT && huntAwaitFirst && !audio.voicePlaying()){ huntAwaitFirst=false; playHuntPrompt(); }
        if(screen==Screen::STORIES && storyAwaitFirst && !audio.voicePlaying()){ storyAwaitFirst=false; playStory(); }
        if(screen==Screen::HUNT&&nextHuntAt&&now>=nextHuntAt){nextHuntAt=0;huntPos++;if(huntPos>=(int)huntOrder.size()){audio.voice("great");spawn(640,360,100);huntPos=0;std::shuffle(huntOrder.begin(),huntOrder.end(),rng);huntAwaitFirst=true;return;}playHuntPrompt();}
    }
    void spawn(float x,float y,int n){std::uniform_real_distribution<float>a(0,6.283f),s(80,260);for(int i=0;i<n;++i){float an=a(rng),sp=s(rng);particles.push_back({x,y,std::cos(an)*sp,std::sin(an)*sp-80,1.3f, palette[i%palette.size()]});}}

    void render(Uint32 now){SDL_SetRenderDrawColor(ren,20,40,60,255);SDL_RenderClear(ren);switch(screen){case Screen::HOME:renderHome();break;case Screen::MORE:renderMore();break;case Screen::ANIMALS:renderAnimals(now);break;case Screen::PUZZLE:renderPuzzle();break;case Screen::COLOR:renderColor();break;case Screen::DRAW:renderDraw();break;case Screen::LETTERS:renderLetters();break;case Screen::NUMBERS:renderNumbers();break;case Screen::HUNT:renderHunt(now);break;case Screen::STORIES:renderStories(now);break;case Screen::SHAPES:renderShapes();break;case Screen::VEHICLES:renderVehicles();break;case Screen::FRUITS:renderFruits();break;}renderParticles();if(fade){SDL_SetRenderDrawColor(ren,0,0,0,fade);SDL_Rect all{0,0,W,H};SDL_RenderFillRect(ren,&all);} }
    void bg(const std::string&k,Uint8 alpha=255){auto&t=textures[k];if(!t.t)return;SDL_SetTextureAlphaMod(t.t,alpha);SDL_Rect d{0,0,W,H};SDL_RenderCopy(ren,t.t,nullptr,&d);SDL_SetTextureAlphaMod(t.t,255);}
    void fill(SDL_Rect r,SDL_Color c){SDL_SetRenderDrawColor(ren,c.r,c.g,c.b,c.a);SDL_RenderFillRect(ren,&r);}
    void outline(SDL_Rect r,SDL_Color c,int n=2){SDL_SetRenderDrawColor(ren,c.r,c.g,c.b,c.a);for(int i=0;i<n;++i){SDL_Rect q{r.x-i,r.y-i,r.w+2*i,r.h+2*i};SDL_RenderDrawRect(ren,&q);}}
    void circle(int cx,int cy,int rad,SDL_Color c){SDL_SetRenderDrawColor(ren,c.r,c.g,c.b,c.a);for(int y=-rad;y<=rad;++y){int x=(int)std::sqrt(std::max(0,rad*rad-y*y));SDL_RenderDrawLine(ren,cx-x,cy+y,cx+x,cy+y);} }
    void text(const std::string&s,int size,int x,int y,SDL_Color c,bool center=false,int wrap=0){TTF_Font*f=fonts.get(size);if(!f)return;SDL_Surface*surf=wrap?TTF_RenderUTF8_Blended_Wrapped(f,s.c_str(),c,wrap):TTF_RenderUTF8_Blended(f,s.c_str(),c);if(!surf)return;SDL_Texture*t=SDL_CreateTextureFromSurface(ren,surf);SDL_Rect d{x,y,surf->w,surf->h};if(center)d.x=x-surf->w/2;SDL_FreeSurface(surf);SDL_RenderCopy(ren,t,nullptr,&d);SDL_DestroyTexture(t);}
    void label(const std::string&s,int size,int x,int y,SDL_Color c=rgba(255,255,255),bool center=true){text(s,size,x+2,y+3,rgba(0,0,0,150),c.a?center:false);text(s,size,x,y,c,center);}
    void backButton(){circle(58,52,42,rgba(20,120,230,235));text("<",52,58,22,rgba(255,255,255),true);}
    void translucent(){fill({0,0,W,H},rgba(0,30,50,90));}

    void renderHome(){bg("home"); if(!audio.isEnabled()){fill({1020,10,160,55},rgba(190,40,40,210));label("SOM OFF",24,1100,24);}}
    void renderMore(){bg("home");translucent();fill({110,115,1060,500},rgba(255,250,235,235));outline({110,115,1060,500},rgba(78,112,52),5);label("MAIS BRINCADEIRAS",52,640,130,rgba(58,92,35));
        struct B{SDL_Rect r;SDL_Color c;const char*t;};std::array<B,6>b{{{{160,190,290,150},rgba(79,190,91),"DESENHO LIVRE"},{{495,190,290,150},rgba(45,150,230),"FORMAS E CORES"},{{830,190,290,150},rgba(245,120,50),"VEICULOS"},{{160,390,290,150},rgba(220,80,140),"FRUTAS E VERDURAS"},{{495,390,290,150},rgba(140,75,225),"NUMEROS"},{{830,390,290,150},rgba(80,100,125),"VOLTAR"}}};for(auto&v:b){fill(v.r,v.c);outline(v.r,rgba(255,255,255),4);label(v.t,28,v.r.x+v.r.w/2,v.r.y+55);}backButton();}
    void renderAnimals(Uint32 now){bg("animals"); // featured card covering the left elephant area
        SDL_Rect card{45,165,390,430};fill(card,rgba(255,255,255,232));outline(card,rgba(70,175,90),5);auto&a=animals[animalIndex];auto&t=textures[a.tex];SDL_Rect img{70,190,340,270};if(t.t)SDL_RenderCopy(ren,t.t,&a.src,&img);fill({70,475,340,90},rgba(20,135,230,235));label(a.name,42,240,490);circle(380,525,32,rgba(35,190,80));label("♪",34,380,503);if((now/650)%2==0)outline(card,rgba(255,230,70),4);backButton();}
    void renderPuzzle(){bg("puzzle");SDL_Rect b=puzzleBoard();fill({b.x-8,b.y-8,b.w+16,b.h+16},rgba(255,255,255,240));auto&t=textures[puzzleScenes[puzzleScene]];int n=puzzleRows*puzzleCols,cw=b.w/puzzleCols,ch=b.h/puzzleRows;int sw=t.w/puzzleCols,sh=t.h/puzzleRows;for(int slot=0;slot<n;++slot){int tile=puzzleOrder[slot],sr=tile/puzzleCols,sc=tile%puzzleCols,dr=slot/puzzleCols,dc=slot%puzzleCols;SDL_Rect src{sc*sw,sr*sh,sw,sh},dst{b.x+dc*cw,b.y+dr*ch,cw,ch};SDL_RenderCopy(ren,t.t,&src,&dst);outline(dst,tile==slot?rgba(70,220,90):rgba(255,255,255),tile==slot?3:1);if(slot==puzzleSelected)fill(dst,rgba(255,230,50,70));}
        // 12 piece button
        fill({1040,570,200,75},rgba(235,65,120,235));outline({1040,570,200,75},rgba(255,255,255),3);label("12 PECAS",27,1140,592);if(puzzleSolved){fill({455,300,440,105},rgba(40,180,70,225));label("MUITO BEM!",48,675,322); }backButton();}
    void renderColor(){bg("home");translucent();label("COLORIR",48,640,22,rgba(255,235,110));fill({245,105,730,540},rgba(255,255,255,245));outline({245,105,730,540},rgba(165,98,45),5);SDL_Rect cv{260,125,700,500};SDL_RenderCopy(ren,colorTex,nullptr,&cv);SDL_SetTextureBlendMode(lineTex,SDL_BLENDMODE_BLEND);SDL_RenderCopy(ren,lineTex,nullptr,&cv); // tools
        const char*tn[]={"PINCEL","MARCADOR","BALDE","BORRACHA","DESFAZER"};for(int i=0;i<5;++i){SDL_Rect r{30,155+i*88,180,70};fill(r,(i==colorTool||i==4&&false)?rgba(245,100,155):rgba(255,250,235,235));outline(r,rgba(120,80,50),2);label(tn[i],22,120,r.y+22,rgba(40,80,130));}
        for(int r=0;r<4;++r)for(int c=0;c<3;++c){int i=r*3+c;circle(1035+c*75,270+r*70,25,palette[i]);if(i==colorColor){SDL_Rect q{1005+c*75,240+r*70,58,58};outline(q,rgba(255,230,70),4);}}
        label("PAGINA "+std::to_string(colorPage+1)+"/4",24,1120,535,rgba(255,255,255));circle(1030,615,34,rgba(40,140,230));label("<",34,1030,595);circle(1200,615,34,rgba(40,140,230));label(">",34,1200,595);backButton();}
    void renderDraw(){bg("home");translucent();label("DESENHO LIVRE",50,640,22,rgba(255,238,120));fill({210,90,850,550},rgba(255,255,255,245));outline({210,90,850,550},rgba(170,100,45),5);SDL_Rect cv{225,105,820,520};SDL_RenderCopy(ren,drawTex,nullptr,&cv);const char*tn[]={"PINCEL FINO","PINCEL MEDIO","PINCEL GROSSO","BORRACHA","DESFAZER"};for(int i=0;i<5;++i){SDL_Rect r{25,180+i*85,170,65};fill(r,rgba(250,245,230,235));outline(r,rgba(90,100,120),2);label(tn[i],19,110,r.y+20,rgba(35,75,120));}for(int r=0;r<6;++r)for(int c=0;c<2;++c){int i=r*2+c;circle(1110+c*70,180+r*70,24,palette[i]);if(i==drawColor)outline({1080+c*70,150+r*70,60,60},rgba(255,230,70),4);}fill({1070,590,160,70},rgba(230,80,80));label("LIMPAR",23,1150,611);backButton();}
    void renderLetters(){bg("letters");fill({225,165,450,405},rgba(255,250,220,236));outline({225,165,450,405},rgba(255,205,80),5);std::string L(1,char('A'+letterIndex));label(L,190,450,185,rgba(230,55,55));label(L+" DE "+letterWords[letterIndex],38,450,450,rgba(215,75,35));circle(450,525,36,rgba(30,130,230));label("♪",38,450,501);fill({300,590,80,65},rgba(30,130,230));label("<",36,340,605);fill({900,590,80,65},rgba(30,130,230));label(">",36,940,605);backButton();}
    void renderNumbers(){bg("home");translucent();label("NUMEROS",54,640,22,rgba(255,236,80));fill({140,120,1000,500},rgba(235,250,255,235));outline({140,120,1000,500},rgba(30,140,220),5);label(std::to_string(numberIndex),200,380,180,rgba(90,65,220));int per=5;for(int i=0;i<numberIndex;++i){int row=i/per,col=i%per;int x=680+col*85,y=230+row*105;circle(x,y,30,rgba(235,60+15*i,60));circle(x+13,y-25,10,rgba(45,180,70));}label("VAMOS CONTAR!",36,830,485,rgba(40,95,145));for(int i=1;i<=10;++i){SDL_Rect r{250+(i-1)*78,590,60,55};fill(r,i==numberIndex?rgba(50,200,80):rgba(40,140,230));label(std::to_string(i),24,r.x+30,r.y+14);}backButton();}
    void renderHunt(Uint32 now){bg("hidden"); if(huntOrder.empty())return;auto&h=hunts[huntOrder[huntPos]];fill({825,15,420,86},rgba(255,255,255,240));outline({825,15,420,86},rgba(30,130,225),4);label("ENCONTRE: "+h.label,30,1035,40,rgba(35,75,150));label(std::to_string(huntFound)+" ENCONTRADOS",25,640,650,rgba(255,255,255));if(nextHuntAt&&((now/120)%2==0)){outline(h.r,rgba(255,235,40),6);}backButton();}
    void renderStories(Uint32 now){bg("stories");std::string tex="story_"+std::string(story==0?"lion":story==1?"elephant":"turtle")+"_"+std::to_string(storyPage+1);auto&t=textures[tex];fill({245,125,790,430},rgba(255,248,225,245));SDL_Rect d{260,140,760,395};SDL_RenderCopy(ren,t.t,nullptr,&d);outline(d,rgba(245,220,145),4);fill({320,145,640,62},rgba(255,255,255,220));label(storyNames[story],30,640,160,rgba(85,55,25)); // pulse interactivity points
        int pulse=28+int(5*std::sin(now/180.0));circle(450,380,pulse,rgba(40,160,250,130));circle(840,350,pulse,rgba(255,210,50,130));fill({150,565,240,90},rgba(245,165,35,240));label("PAGINA ANTERIOR",23,270,590);fill({890,565,240,90},rgba(65,195,70,240));label("PROXIMA PAGINA",23,1010,590);for(int i=0;i<3;++i){SDL_Rect r{435+i*155,575,140,65};fill(r,i==story?rgba(55,180,80):rgba(40,130,220));label(i==0?"LEAO":i==1?"ELEFANTE":"TARTARUGA",18,r.x+70,r.y+22);}label("PAGINA "+std::to_string(storyPage+1)+"/3",22,640,535,rgba(255,255,255));backButton();}
    void renderShapes(){bg("home");translucent();label("FORMAS E CORES",52,640,35,rgba(255,240,100));std::array<const char*,6>n{{"CIRCULO VERMELHO","QUADRADO AZUL","TRIANGULO AMARELO","ESTRELA VERDE","CORACAO ROSA","LOSANGO ROXO"}};std::array<SDL_Color,6>c{{rgba(235,60,60),rgba(45,120,230),rgba(255,205,40),rgba(50,190,80),rgba(240,80,145),rgba(145,70,220)}};for(int i=0;i<6;++i){int col=i%3,row=i/3;SDL_Rect card{150+col*315,180+row*200,270,160};fill(card,rgba(255,255,255,235));outline(card,i==selectedShape?rgba(255,230,50):rgba(90,120,140),i==selectedShape?5:2);int cx=card.x+135,cy=card.y+62;if(i==0)circle(cx,cy,42,c[i]);else if(i==1)fill({cx-42,cy-42,84,84},c[i]);else if(i==2){SDL_SetRenderDrawColor(ren,c[i].r,c[i].g,c[i].b,255);for(int y=0;y<85;++y){int half=y/2;SDL_RenderDrawLine(ren,cx-half,cy-42+y,cx+half,cy-42+y);}}else if(i==3)star(cx,cy,48,c[i]);else if(i==4)heart(cx,cy,42,c[i]);else diamond(cx,cy,45,c[i]);label(n[i],19,cx,card.y+120,rgba(50,70,95));}backButton();}
    void renderVehicles(){bg("home");translucent();label("VEICULOS",54,640,35,rgba(255,235,90));static const char*n[]={"CARRO","ONIBUS","CAMINHAO","AVIAO","TREM","BARCO","BICICLETA","HELICOPTERO"};for(int i=0;i<8;++i){int col=i%4,row=i/4;SDL_Rect card{105+col*275,175+row*205,245,170};fill(card,rgba(255,255,255,235));outline(card,i==selectedVehicle?rgba(255,230,50):rgba(80,110,140),i==selectedVehicle?5:2);vehicleIcon(i,card.x+122,card.y+72);label(n[i],21,card.x+122,card.y+132,rgba(45,70,100));}backButton();}
    void renderFruits(){bg("home");translucent();label("FRUTAS E VERDURAS",48,640,35,rgba(255,235,90));static const char*n[]={"MACA","BANANA","LARANJA","UVA","CENOURA","BROCOLIS","MORANGO","PERA"};for(int i=0;i<8;++i){int col=i%4,row=i/4;SDL_Rect card{105+col*275,175+row*205,245,170};fill(card,rgba(255,255,255,235));outline(card,i==selectedFruit?rgba(255,230,50):rgba(80,110,140),i==selectedFruit?5:2);fruitIcon(i,card.x+122,card.y+70);label(n[i],21,card.x+122,card.y+132,rgba(45,70,100));}backButton();}
    void renderParticles(){for(auto&p:particles){Uint8 a=(Uint8)(255*std::clamp(p.life/1.3f,0.f,1.f));circle((int)p.x,(int)p.y,6,rgba(p.c.r,p.c.g,p.c.b,a));}}
    void star(int cx,int cy,int r,SDL_Color c){std::array<SDL_Point,11>p{};for(int i=0;i<10;++i){float a=-M_PI/2+i*M_PI/5;float rr=(i%2?0.45f:1.f)*r;p[i]={int(cx+std::cos(a)*rr),int(cy+std::sin(a)*rr)};}p[10]=p[0];SDL_SetRenderDrawColor(ren,c.r,c.g,c.b,c.a);for(int i=0;i<10;++i)SDL_RenderDrawLine(ren,p[i].x,p[i].y,p[i+1].x,p[i+1].y);for(int y=-r;y<=r;++y)for(int x=-r;x<=r;++x){ // cheap radial fill to keep icon lively
            if(x*x+y*y<r*r/3){SDL_RenderDrawPoint(ren,cx+x,cy+y);} }
    }
    void heart(int cx,int cy,int r,SDL_Color c){circle(cx-r/2,cy-r/4,r/2,c);circle(cx+r/2,cy-r/4,r/2,c);SDL_SetRenderDrawColor(ren,c.r,c.g,c.b,c.a);for(int y=0;y<r;++y){int half=(r-y);SDL_RenderDrawLine(ren,cx-half,cy+y/2,cx+half,cy+y/2);} }
    void diamond(int cx,int cy,int r,SDL_Color c){SDL_SetRenderDrawColor(ren,c.r,c.g,c.b,c.a);for(int y=-r;y<=r;++y){int half=r-std::abs(y);SDL_RenderDrawLine(ren,cx-half,cy+y,cx+half,cy+y);} }
    void vehicleIcon(int i,int cx,int cy){SDL_Color c=palette[(i*2)%palette.size()];if(i<=2){fill({cx-70,cy-25,140,50},c);fill({cx-35,cy-55,70,35},c);circle(cx-45,cy+30,18,rgba(40,40,45));circle(cx+45,cy+30,18,rgba(40,40,45));}else if(i==3){fill({cx-75,cy-8,150,18},c);SDL_SetRenderDrawColor(ren,c.r,c.g,c.b,255);for(int y=-45;y<=45;++y){int half=std::max(0,65-std::abs(y));SDL_RenderDrawLine(ren,cx-half,cy+y,cx+half,cy+y);} }else if(i==4){fill({cx-75,cy-30,150,55},c);circle(cx-45,cy+30,17,rgba(40,40,45));circle(cx+45,cy+30,17,rgba(40,40,45));fill({cx-25,cy-60,50,30},rgba(60,60,70));}else if(i==5){SDL_SetRenderDrawColor(ren,c.r,c.g,c.b,255);for(int y=0;y<45;++y){int half=80-y;SDL_RenderDrawLine(ren,cx-half,cy-20+y,cx+half,cy-20+y);}fill({cx-4,cy-70,8,55},rgba(80,60,40));}else if(i==6){circle(cx-45,cy+22,32,rgba(40,40,45));circle(cx+45,cy+22,32,rgba(40,40,45));SDL_SetRenderDrawColor(ren,c.r,c.g,c.b,255);SDL_RenderDrawLine(ren,cx-45,cy+22,cx,cy-25);SDL_RenderDrawLine(ren,cx,cy-25,cx+45,cy+22);SDL_RenderDrawLine(ren,cx-45,cy+22,cx+20,cy+22);}else{fill({cx-55,cy-20,110,40},c);SDL_SetRenderDrawColor(ren,50,50,55,255);SDL_RenderDrawLine(ren,cx-95,cy-45,cx+95,cy-45);SDL_RenderDrawLine(ren,cx,cy-65,cx,cy-25);}}
    void fruitIcon(int i,int cx,int cy){if(i==0){circle(cx,cy,45,rgba(230,55,55));circle(cx+20,cy-42,13,rgba(50,180,60));}else if(i==1){SDL_SetRenderDrawColor(ren,250,210,40,255);for(int a=0;a<50;++a){float ang=(20+a)*M_PI/180;SDL_RenderDrawLine(ren,cx-55+int(std::cos(ang)*70),cy-35+int(std::sin(ang)*55),cx-55+int(std::cos(ang)*80),cy-35+int(std::sin(ang)*65));}}else if(i==2)circle(cx,cy,45,rgba(245,135,35));else if(i==3){for(int y=0;y<3;++y)for(int x=0;x<3-y;++x)circle(cx+(x*30)-(30-y*15),cy-20+y*28,18,rgba(125,55,175));}else if(i==4){SDL_SetRenderDrawColor(ren,245,115,35,255);for(int y=0;y<75;++y){int half=35-y/2;SDL_RenderDrawLine(ren,cx-half,cy-35+y,cx+half,cy-35+y);}circle(cx,cy-48,25,rgba(55,180,65));}else if(i==5){fill({cx-10,cy+10,20,45},rgba(60,150,55));circle(cx-30,cy,32,rgba(45,170,70));circle(cx+30,cy,32,rgba(45,170,70));circle(cx,cy-25,35,rgba(50,190,75));}else if(i==6){heart(cx,cy,48,rgba(235,60,75));circle(cx,cy-46,15,rgba(45,165,60));}else{SDL_SetRenderDrawColor(ren,100,190,60,255);for(int y=-50;y<=50;++y){int half=int(42*std::sqrt(std::max(0.0,1.0-y*y/2500.0)));SDL_RenderDrawLine(ren,cx-half,cy+y,cx+half,cy+y);}circle(cx+15,cy-48,12,rgba(45,150,55));}}
};

int main(int argc,char**argv){(void)argc;(void)argv;Game g;if(!g.init())return 1;g.loop();return 0;}

#!/usr/bin/env python3
from PIL import Image, ImageFilter, ImageOps, ImageEnhance
from pathlib import Path
A=Path('romfs/assets')

def crop_zoom(name,crops):
    im=Image.open(A/f'story_{name}_1.jpg').convert('RGB')
    for i,c in enumerate(crops,2):
        im.crop(c).resize((1280,720),Image.Resampling.LANCZOS).save(A/f'story_{name}_{i}.jpg',quality=84,optimize=True)

crop_zoom('lion',[(0,40,800,650),(450,60,1280,680)])
crop_zoom('elephant',[(120,40,900,680),(500,40,1280,680)])
crop_zoom('turtle',[(200,20,1000,690),(560,80,1280,700)])

def make_line(im,path,size=(900,520)):
    im=im.convert('L').resize(size,Image.Resampling.LANCZOS)
    im=ImageEnhance.Contrast(im).enhance(1.35)
    edges=ImageOps.invert(im.filter(ImageFilter.FIND_EDGES))
    edges=edges.point(lambda p:0 if p<218 else 255).filter(ImageFilter.MedianFilter(3))
    edges.save(path,optimize=True)

animals=Image.open(A/'animals.jpg').convert('RGB')
make_line(animals.crop((60,165,410,390)),A/'line_elephant.png')
make_line(animals.crop((720,160,970,405)),A/'line_giraffe.png')
tur=Image.open(A/'story_turtle_1.jpg').convert('RGB')
make_line(tur.crop((300,80,1050,680)),A/'line_turtle.png')
print('Prepared derived story/coloring assets')

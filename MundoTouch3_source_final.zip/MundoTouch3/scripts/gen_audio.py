#!/usr/bin/env python3
import asyncio, math, os, random, struct, subprocess, wave
from pathlib import Path

OUT=Path('romfs/audio'); OUT.mkdir(parents=True,exist_ok=True)
VOICE='pt-BR-FranciscaNeural'
PHRASES={
'welcome':'Bem-vindo ao Mundo Touch! Toque em uma brincadeira para começar.',
'home_more':'Temos ainda mais brincadeiras! Escolha uma atividade.',
'animals_intro':'Toque em um animal para ouvir o nome e o som que ele faz.',
'puzzle_intro':'Monte a figura. Toque em uma peça e depois no lugar onde você quer colocar.',
'puzzle_done':'Muito bem! Você montou o quebra-cabeça!',
'color_intro':'Escolha uma cor e pinte o desenho. Você também pode usar o balde de tinta.',
'draw_intro':'Desenho livre! Escolha uma cor e desenhe tudo o que imaginar.',
'letters_intro':'Vamos aprender as letras. Toque nas setas para descobrir novas letras.',
'numbers_intro':'Vamos aprender os números e contar juntos.',
'hunt_intro':'Preste atenção. Eu vou pedir um objeto. Procure e toque nele quando encontrar.',
'stories_intro':'Escolha uma história. Vire as páginas e ouça a narração.',
'shapes_intro':'Toque em uma forma para ouvir o nome e a cor.',
'vehicles_intro':'Toque em um veículo para descobrir o nome dele.',
'fruits_intro':'Toque em uma fruta ou verdura para descobrir o nome dela.',
'good':'Muito bem!', 'great':'Parabéns! Você conseguiu!', 'retry':'Quase! Procure mais um pouquinho.',
'page':'Próxima página.', 'back':'Voltando.',
}
animals={
'elefante':('Este é o elefante. O elefante faz assim.','snd_elephant'),
'leao':('Este é o leão. O leão ruge.','snd_lion'),
'girafa':('Esta é a girafa. A girafa faz um som bem baixinho.','snd_giraffe'),
'macaco':('Este é o macaco. O macaco faz assim.','snd_monkey'),
'vaca':('Esta é a vaca. A vaca faz mu.','snd_cow'),
'pato':('Este é o pato. O pato faz quá quá.','snd_duck'),
'cachorro':('Este é o cachorro. O cachorro faz au au.','snd_dog'),
'urso':('Este é o urso. O urso faz assim.','snd_bear'),
'sapo':('Este é o sapo. O sapo coaxa.','snd_frog'),
'passaro':('Este é o passarinho. Ele canta assim.','snd_bird'),
'tartaruga':('Esta é a tartaruga. Ela é tranquila e adora nadar.','snd_turtle'),
'peixe':('Este é o peixe. Ele nada na água.','snd_fish'),
}
for k,(t,_) in animals.items(): PHRASES['animal_'+k]=t
letters=[('A','abelha'),('B','bola'),('C','cachorro'),('D','dado'),('E','elefante'),('F','flor'),('G','gato'),('H','hipopótamo'),('I','ilha'),('J','jacaré'),('K','kiwi'),('L','leão'),('M','macaco'),('N','navio'),('O','ovelha'),('P','pato'),('Q','queijo'),('R','rato'),('S','sapo'),('T','tartaruga'),('U','uva'),('V','vaca'),('W','waffle'),('X','xilofone'),('Y','yak'),('Z','zebra')]
for i,(l,w) in enumerate(letters): PHRASES[f'letter_{i:02d}']=f'{l}. {l} de {w}.'
nums=['um','dois','três','quatro','cinco','seis','sete','oito','nove','dez']
for i,n in enumerate(nums,1):
    count=', '.join(nums[:i])
    PHRASES[f'number_{i:02d}']=f'Este é o número {i}. Vamos contar: {count}.'
hunt={'bola':'Encontre a bola!','urso':'Encontre o ursinho!','carro':'Encontre o carro vermelho!','bicicleta':'Encontre a bicicleta!','maca':'Encontre a maçã!','banana':'Encontre a banana!','girafa':'Encontre a girafa!','pato':'Encontre o pato!','numero3':'Encontre o número três!','letraA':'Encontre a letra A!','laranja':'Encontre a laranja!','macaco':'Encontre o macaco!','mochila':'Encontre a mochila azul!','pipa':'Encontre a pipa!','sapo':'Encontre o sapo!'}
for k,t in hunt.items(): PHRASES['hunt_'+k]=t
shapes={'circle':'Este é um círculo vermelho.','square':'Este é um quadrado azul.','triangle':'Este é um triângulo amarelo.','star':'Esta é uma estrela verde.','heart':'Este é um coração rosa.','diamond':'Este é um losango roxo.'}
for k,t in shapes.items(): PHRASES['shape_'+k]=t
vehicles={'car':'Este é o carro.','bus':'Este é o ônibus.','truck':'Este é o caminhão.','plane':'Este é o avião.','train':'Este é o trem.','boat':'Este é o barco.','bike':'Esta é a bicicleta.','helicopter':'Este é o helicóptero.'}
for k,t in vehicles.items(): PHRASES['vehicle_'+k]=t
fruits={'apple':'Esta é a maçã.','banana':'Esta é a banana.','orange':'Esta é a laranja.','grape':'Esta é a uva.','carrot':'Esta é a cenoura.','broccoli':'Este é o brócolis.','strawberry':'Este é o morango.','pear':'Esta é a pera.'}
for k,t in fruits.items(): PHRASES['fruit_'+k]=t
stories=[
('lion_1','Era uma vez um leãozinho muito curioso, que adorava explorar a floresta e ouvir os sons da natureza.'),
('lion_2','Um dia, ele seguiu uma linda borboleta e encontrou um passarinho cantando perto de uma árvore enorme.'),
('lion_3','Perto do rio, o leãozinho conheceu um sapinho. Os dois brincaram juntos e descobriram que novos amigos tornam qualquer aventura melhor.'),
('elephant_1','O elefantinho caminhava pelas montanhas quando ouviu um patinho chamando do outro lado da ponte.'),
('elephant_2','Com calma e coragem, ele atravessou a ponte e mostrou ao patinho o caminho seguro.'),
('elephant_3','Os animais da floresta ficaram felizes. O elefantinho aprendeu que ser corajoso também é cuidar dos amigos.'),
('turtle_1','No fundo do mar vivia uma tartaruguinha que gostava de conhecer cada pedacinho do recife.'),
('turtle_2','Ela encontrou um peixinho e um cavalo-marinho procurando uma concha brilhante que havia desaparecido.'),
('turtle_3','Juntos, eles acharam a concha entre os corais. A tartaruguinha descobriu que trabalhar em equipe deixa a aventura ainda mais divertida.'),
]
for k,t in stories: PHRASES['story_'+k]=t

async def neural(key,text):
    mp3=OUT/(key+'.mp3'); wav=OUT/(key+'.wav')
    try:
        import edge_tts
        c=edge_tts.Communicate(text,VOICE,rate='-5%',volume='+5%')
        await c.save(str(mp3))
        subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(mp3),'-ac','1','-ar','22050','-af','loudnorm=I=-16:TP=-2:LRA=7',str(wav)],check=True)
        mp3.unlink(missing_ok=True)
        return True
    except Exception as e:
        print('Neural TTS failed for',key,e)
        return False

def fallback(key,text):
    wav=OUT/(key+'.wav'); tmp=OUT/(key+'_tmp.wav')
    subprocess.run(['espeak-ng','-v','pt-br','-s','145','-p','55','-a','180','-w',str(tmp),text],check=True)
    subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(tmp),'-ac','1','-ar','22050','-af','loudnorm=I=-16:TP=-2:LRA=7',str(wav)],check=True)
    tmp.unlink(missing_ok=True)

async def generate_all():
    sem=asyncio.Semaphore(5)
    async def one(k,t):
        async with sem:
            if (OUT/(k+'.wav')).exists(): return
            ok=await neural(k,t)
            if not ok: fallback(k,t)
    await asyncio.gather(*(one(k,t) for k,t in PHRASES.items()))

def save_wave(name, samples, sr=22050):
    path=OUT/(name+'.wav')
    mx=max(1e-6,max(abs(x) for x in samples)); scale=0.82/mx
    with wave.open(str(path),'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        data=bytearray()
        for x in samples:
            v=max(-1,min(1,x*scale)); data += struct.pack('<h',int(v*32767))
        w.writeframes(data)

def env(t,d,a=.02,r=.25):
    if t<a: return t/a
    if t>d-r: return max(0,(d-t)/r)
    return 1.0

def tone_sweep(d,f0,f1,harm=1.0,noise=0.0,amp=1.0,sr=22050):
    out=[]; phase=0.0; n=int(d*sr)
    for i in range(n):
        t=i/sr; f=f0+(f1-f0)*(t/d); phase+=2*math.pi*f/sr
        v=math.sin(phase)+0.35*math.sin(2*phase)*harm+0.15*math.sin(3*phase)*harm
        v += noise*random.uniform(-1,1)
        out.append(v*env(t,d)*amp)
    return out

def silence(d,sr=22050): return [0.0]*int(d*sr)
def concat(*parts):
    out=[]
    for p in parts: out.extend(p)
    return out

def sfx():
    save_wave('click', tone_sweep(.09,700,1100,.3,.02,.5))
    save_wave('success', concat(tone_sweep(.16,520,780,.4,0,.6),tone_sweep(.20,780,1050,.4,0,.7),tone_sweep(.25,1050,1320,.4,0,.8)))
    save_wave('pop', tone_sweep(.13,350,900,.2,.02,.5))
    save_wave('page_turn', tone_sweep(.28,200,120,.1,.4,.4))
    save_wave('snd_dog', concat(tone_sweep(.22,220,150,.8,.45,.8),silence(.08),tone_sweep(.20,240,160,.8,.45,.8)))
    save_wave('snd_cow', tone_sweep(1.1,115,82,1,.15,1))
    save_wave('snd_lion', tone_sweep(1.0,95,60,1,.75,1))
    save_wave('snd_elephant', tone_sweep(.85,420,900,.8,.15,1))
    save_wave('snd_monkey', concat(tone_sweep(.20,600,950,.5,.1,.8),silence(.05),tone_sweep(.18,850,500,.5,.1,.8),silence(.05),tone_sweep(.16,700,1000,.5,.1,.8)))
    save_wave('snd_giraffe', tone_sweep(.45,140,110,.8,.12,.5))
    save_wave('snd_duck', concat(tone_sweep(.15,350,240,.9,.25,.7),silence(.05),tone_sweep(.15,360,250,.9,.25,.7)))
    save_wave('snd_bear', tone_sweep(.7,90,70,.8,.5,.8))
    save_wave('snd_frog', concat(tone_sweep(.18,180,110,.7,.1,.7),silence(.08),tone_sweep(.18,190,120,.7,.1,.7)))
    save_wave('snd_bird', concat(tone_sweep(.12,1200,1800,.3,0,.5),silence(.06),tone_sweep(.10,1600,1100,.3,0,.5),silence(.06),tone_sweep(.13,1300,2000,.3,0,.5)))
    save_wave('snd_turtle', concat(tone_sweep(.15,500,300,.2,.15,.25),silence(.10),tone_sweep(.12,650,400,.2,.15,.22)))
    save_wave('snd_fish', concat(tone_sweep(.08,900,500,.2,.05,.25),silence(.05),tone_sweep(.08,700,450,.2,.05,.2)))
    # aliases for animals already synthesized
    save_wave('snd_horse', tone_sweep(.8,380,680,.7,.18,.7))
    # Gentle looping background music (simple major pentatonic glockenspiel-like bed).
    sr=22050; dur=32.0; n=int(sr*dur); music=[0.0]*n
    notes=[261.63,329.63,392.00,523.25,392.00,329.63,293.66,349.23,440.00,587.33,440.00,349.23]
    step=0.5
    for j,f in enumerate(notes*6):
        start=int(j*step*sr)
        if start>=n: break
        length=int(.42*sr)
        for i in range(min(length,n-start)):
            t=i/sr; e=math.exp(-4.2*t)
            v=(math.sin(2*math.pi*f*t)+0.28*math.sin(4*math.pi*f*t))*e*0.14
            music[start+i]+=v
    # soft sustained pad
    chords=[(130.81,164.81,196.00),(146.83,174.61,220.00),(130.81,164.81,196.00),(110.00,146.83,164.81)]
    for cidx,ch in enumerate(chords):
        start=int(cidx*8*sr); length=min(int(8*sr),n-start)
        for i in range(length):
            t=i/sr; e=min(1,t/.8)*min(1,(8-t)/.8)
            music[start+i]+=sum(math.sin(2*math.pi*f*t) for f in ch)*0.018*max(0,e)
    save_wave('music', music, sr)

if __name__=='__main__':
    asyncio.run(generate_all()); sfx(); print('Audio files:',len(list(OUT.glob('*.wav'))))
